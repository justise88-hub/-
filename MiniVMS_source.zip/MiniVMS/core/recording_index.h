#pragma once

#include <QList>
#include <QString>

struct SegmentInfo {
    qint64 id = -1;
    QString cameraId;
    QString path;
    qint64 startMs = 0;   // UTC, мс от эпохи
    qint64 endMs = 0;     // 0, если сегмент ещё пишется
    qint64 sizeBytes = 0;
};

// Индекс сегментов архива в SQLite.
//
// ВАЖНО: соединение QSqlDatabase нельзя передавать между потоками, поэтому
// каждый объект RecordingIndex нужно создавать и вызывать open() в том потоке,
// где он будет использоваться (в CameraWorker::run() и отдельно в GUI-потоке).
// Несколько соединений к одному файлу работают штатно (включён режим WAL).
class RecordingIndex {
public:
    RecordingIndex() = default;
    ~RecordingIndex();
    RecordingIndex(const RecordingIndex &) = delete;
    RecordingIndex &operator=(const RecordingIndex &) = delete;

    bool open(const QString &dbPath);   // открывает соединение и создаёт схему
    void close();
    QString lastError() const { return m_lastError; }

    // Запись
    qint64 beginSegment(const QString &cameraId, const QString &path, qint64 startMs);
    bool endSegment(qint64 id, qint64 endMs, qint64 sizeBytes);
    // После сбоя/краша остаются сегменты без end_ms: восстановить по файлу или удалить.
    void closeDanglingSegments(const QString &cameraId);

    // Чтение (для архива и таймлайна)
    QList<SegmentInfo> segmentsInRange(const QString &cameraId, qint64 fromMs, qint64 toMs);
    SegmentInfo segmentAt(const QString &cameraId, qint64 ms);   // id == -1, если записи нет

private:
    QString m_conn;
    QString m_lastError;
};
