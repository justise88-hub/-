#include "core/camera_worker.h"
#include "core/recording_index.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QScopeGuard>

#include <cerrno>
#include <cstdint>
#include <vector>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>
#include <libavutil/error.h>
}

namespace {

QString avErr(int code)
{
    char buf[AV_ERROR_MAX_STRING_SIZE] = {};
    av_strerror(code, buf, sizeof buf);
    return QString::fromUtf8(buf);
}

// Пишет один mkv-сегмент: копирует видео (и аудио, если mkv его поддерживает)
// из входного потока, сдвигая метки времени так, чтобы сегмент начинался с 0.
class SegmentWriter {
public:
    ~SegmentWriter() { close(); }

    bool isOpen() const { return m_oc != nullptr; }

    bool open(const QString &path, const AVFormatContext *in, QString *err)
    {
        m_path = path;
        const QByteArray fn = QFile::encodeName(path);

        int r = avformat_alloc_output_context2(&m_oc, nullptr, "matroska", fn.constData());
        if (r < 0 || !m_oc)
            return fail(err, QStringLiteral("alloc_output_context2"), r < 0 ? r : AVERROR(ENOMEM));

        m_map.assign(in->nb_streams, -1);
        m_lastDts.assign(in->nb_streams, INT64_MIN);

        for (unsigned i = 0; i < in->nb_streams; ++i) {
            const AVCodecParameters *par = in->streams[i]->codecpar;
            if (par->codec_type != AVMEDIA_TYPE_VIDEO && par->codec_type != AVMEDIA_TYPE_AUDIO)
                continue;
            // экзотический аудиокодек, который mkv не принимает: пишем только видео
            if (par->codec_type == AVMEDIA_TYPE_AUDIO
                && avformat_query_codec(m_oc->oformat, par->codec_id, FF_COMPLIANCE_NORMAL) != 1)
                continue;

            AVStream *os = avformat_new_stream(m_oc, nullptr);
            if (!os)
                return fail(err, QStringLiteral("new_stream"), AVERROR(ENOMEM));
            r = avcodec_parameters_copy(os->codecpar, par);
            if (r < 0)
                return fail(err, QStringLiteral("parameters_copy"), r);
            os->codecpar->codec_tag = 0;
            m_map[i] = os->index;
        }

        r = avio_open(&m_oc->pb, fn.constData(), AVIO_FLAG_WRITE);
        if (r < 0)
            return fail(err, QStringLiteral("avio_open"), r);
        r = avformat_write_header(m_oc, nullptr);
        if (r < 0)
            return fail(err, QStringLiteral("write_header"), r);
        m_headerWritten = true;
        return true;
    }

    // 0 — пакет записан или пропущен, <0 — ошибка записи.
    // Пакет после вызова больше не нужен (av_packet_unref вызывать можно).
    int write(AVPacket *pkt, const AVStream *in)
    {
        const int idx = pkt->stream_index;
        if (idx < 0 || idx >= int(m_map.size()) || m_map[idx] < 0)
            return 0;
        const int o = m_map[idx];
        AVStream *os = m_oc->streams[o];

        int64_t dts = pkt->dts, pts = pkt->pts;
        if (dts == AV_NOPTS_VALUE) dts = pts;
        if (pts == AV_NOPTS_VALUE) pts = dts;
        if (dts == AV_NOPTS_VALUE) return 0;

        // Точка отсчёта сегмента — dts первого записанного пакета (ключевой кадр видео).
        if (m_baseTs == AV_NOPTS_VALUE) {
            m_baseTs = dts;
            m_baseTb = in->time_base;
        }
        const int64_t off = av_rescale_q(m_baseTs, m_baseTb, in->time_base);
        dts -= off;
        pts -= off;
        if (dts < 0)
            return 0;   // аудио, пришедшее раньше первого ключевого кадра

        dts = av_rescale_q(dts, in->time_base, os->time_base);
        pts = av_rescale_q(pts, in->time_base, os->time_base);
        const int64_t dur = pkt->duration > 0
            ? av_rescale_q(pkt->duration, in->time_base, os->time_base) : 0;

        // mkv требует неубывающих dts; RTSP-камеры иногда присылают повторы
        if (dts <= m_lastDts[o]) dts = m_lastDts[o] + 1;
        if (pts < dts) pts = dts;
        m_lastDts[o] = dts;

        pkt->pts = pts;
        pkt->dts = dts;
        pkt->duration = dur;
        pkt->stream_index = o;
        pkt->pos = -1;
        return av_interleaved_write_frame(m_oc, pkt);
    }

    // Закрывает файл, возвращает его размер в байтах.
    qint64 close()
    {
        if (!m_oc)
            return 0;
        if (m_headerWritten)
            av_write_trailer(m_oc);
        if (m_oc->pb)
            avio_closep(&m_oc->pb);
        avformat_free_context(m_oc);
        m_oc = nullptr;
        m_headerWritten = false;
        m_baseTs = AV_NOPTS_VALUE;
        return QFileInfo(m_path).size();
    }

private:
    bool fail(QString *err, const QString &what, int code)
    {
        if (err)
            *err = what + QStringLiteral(": ") + avErr(code);
        if (m_oc) {
            if (m_oc->pb)
                avio_closep(&m_oc->pb);
            avformat_free_context(m_oc);
            m_oc = nullptr;
        }
        m_headerWritten = false;
        return false;
    }

    AVFormatContext *m_oc = nullptr;
    QString m_path;
    bool m_headerWritten = false;
    std::vector<int> m_map;          // индекс входного потока -> индекс выходного (или -1)
    std::vector<int64_t> m_lastDts;  // по выходным потокам
    int64_t m_baseTs = AV_NOPTS_VALUE;
    AVRational m_baseTb = {1, 1};
};

} // namespace

// ---------------------------------------------------------------------------

CameraWorker::CameraWorker(CameraConfig cfg, QObject *parent)
    : QThread(parent), m_cfg(std::move(cfg))
{
}

CameraWorker::~CameraWorker()
{
    stop();
    wait();
}

void CameraWorker::startRecording()
{
    m_stop = false;
    start();
}

void CameraWorker::stop()
{
    m_stop = true;
}

int CameraWorker::interruptCallback(void *opaque)
{
    auto *self = static_cast<CameraWorker *>(opaque);
    if (self->m_stop)
        return 1;
    const qint64 deadline = self->m_deadlineMs.load();
    return (deadline > 0 && QDateTime::currentMSecsSinceEpoch() > deadline) ? 1 : 0;
}

void CameraWorker::armDeadline(int ms)
{
    m_deadlineMs = QDateTime::currentMSecsSinceEpoch() + ms;
}

void CameraWorker::sleepInterruptible(int ms)
{
    for (int waited = 0; waited < ms && !m_stop; waited += 100)
        msleep(100);
}

QString CameraWorker::segmentPath(qint64 startMs) const
{
    const QDateTime t = QDateTime::fromMSecsSinceEpoch(startMs);
    const QString dir = QStringLiteral("%1/%2/%3")
                            .arg(m_cfg.storageRoot, m_cfg.id, t.toString(QStringLiteral("yyyy/MM/dd")));
    QDir().mkpath(dir);
    return QStringLiteral("%1/%2_%3.mkv")
        .arg(dir, m_cfg.id, t.toString(QStringLiteral("yyyyMMdd_HHmmss")));
}

void CameraWorker::run()
{
    // Соединение с БД должно жить в том же потоке, где используется.
    RecordingIndex index;
    if (!index.open(m_cfg.dbPath)) {
        emit errorOccurred(m_cfg.id, tr("Не удалось открыть БД: %1").arg(index.lastError()));
        emit stateChanged(m_cfg.id, State::Stopped);
        return;
    }
    index.closeDanglingSegments(m_cfg.id);

    int backoffMs = 1000;
    while (!m_stop) {
        emit stateChanged(m_cfg.id, State::Connecting);

        bool gotData = false;
        recordSession(index, gotData);
        if (m_stop)
            break;

        emit stateChanged(m_cfg.id, State::Reconnecting);
        backoffMs = gotData ? 1000 : qMin(backoffMs * 2, 30000);
        sleepInterruptible(backoffMs);
    }
    emit stateChanged(m_cfg.id, State::Stopped);
}

// Одна сессия: подключились -> читаем пакеты -> пишем сегменты -> вышли при обрыве или stop().
void CameraWorker::recordSession(RecordingIndex &index, bool &gotData)
{
    AVFormatContext *ic = avformat_alloc_context();
    if (!ic) {
        emit errorOccurred(m_cfg.id, tr("Не хватает памяти"));
        return;
    }
    ic->interrupt_callback.callback = &CameraWorker::interruptCallback;
    ic->interrupt_callback.opaque = this;

    AVDictionary *opts = nullptr;
    av_dict_set(&opts, "rtsp_transport", "tcp", 0);
    av_dict_set(&opts, "timeout",
                QByteArray::number(qint64(m_cfg.ioTimeoutMs) * 1000).constData(), 0);  // мкс

    armDeadline(m_cfg.ioTimeoutMs);
    int r = avformat_open_input(&ic, m_cfg.url.toUtf8().constData(), nullptr, &opts);
    av_dict_free(&opts);
    if (r < 0) {   // при ошибке ic уже освобождён
        emit errorOccurred(m_cfg.id, tr("Не удалось подключиться: %1").arg(avErr(r)));
        return;
    }
    auto closeInput = qScopeGuard([&] { avformat_close_input(&ic); });

    armDeadline(m_cfg.ioTimeoutMs * 2);
    r = avformat_find_stream_info(ic, nullptr);
    if (r < 0) {
        emit errorOccurred(m_cfg.id, tr("Не удалось получить параметры потока: %1").arg(avErr(r)));
        return;
    }
    const int videoIdx = av_find_best_stream(ic, AVMEDIA_TYPE_VIDEO, -1, -1, nullptr, 0);
    if (videoIdx < 0) {
        emit errorOccurred(m_cfg.id, tr("В потоке нет видео"));
        return;
    }

    AVPacket *pkt = av_packet_alloc();
    auto freePkt = qScopeGuard([&] { av_packet_free(&pkt); });

    SegmentWriter writer;
    QString segPath;
    qint64 segId = -1, segStartMs = 0, lastPktMs = 0;
    bool announcedRecording = false;

    auto finishSegment = [&] {
        if (!writer.isOpen())
            return;
        const qint64 size = writer.close();
        if (segId >= 0)
            index.endSegment(segId, lastPktMs, size);
        emit segmentFinished(m_cfg.id, segPath, segStartMs, lastPktMs, size);
        segId = -1;
    };
    // Закрыть сегмент при любом выходе из функции (обрыв, ошибка, stop)
    auto closeSegment = qScopeGuard(finishSegment);

    const qint64 segmentMs = qint64(m_cfg.segmentSeconds) * 1000;

    while (!m_stop) {
        armDeadline(m_cfg.ioTimeoutMs);
        r = av_read_frame(ic, pkt);
        if (r < 0) {
            if (!m_stop)
                emit errorOccurred(m_cfg.id, tr("Поток прерван: %1").arg(avErr(r)));
            break;
        }
        gotData = true;

        const bool isKey = pkt->stream_index == videoIdx && (pkt->flags & AV_PKT_FLAG_KEY);
        const qint64 now = QDateTime::currentMSecsSinceEpoch();

        // Ротация только на ключевом кадре, чтобы каждый сегмент проигрывался сам по себе
        if (writer.isOpen() && isKey && now - segStartMs >= segmentMs)
            finishSegment();

        if (!writer.isOpen()) {
            if (!isKey) {                       // ждём ключевой кадр
                av_packet_unref(pkt);
                continue;
            }
            segStartMs = now;
            segPath = segmentPath(segStartMs);
            QString err;
            if (!writer.open(segPath, ic, &err)) {
                emit errorOccurred(m_cfg.id, tr("Не удалось создать сегмент: %1").arg(err));
                av_packet_unref(pkt);
                break;
            }
            segId = index.beginSegment(m_cfg.id, segPath, segStartMs);
            if (segId < 0)
                emit errorOccurred(m_cfg.id, tr("Ошибка индекса: %1").arg(index.lastError()));
            emit segmentStarted(m_cfg.id, segPath, segStartMs);
            if (!announcedRecording) {
                announcedRecording = true;
                emit stateChanged(m_cfg.id, State::Recording);
            }
        }

        lastPktMs = now;
        // Сюда же позже: копия пакета в декодер для живого просмотра и аналитики.
        const int wr = writer.write(pkt, ic->streams[pkt->stream_index]);
        av_packet_unref(pkt);
        if (wr < 0) {
            emit errorOccurred(m_cfg.id, tr("Ошибка записи (диск?): %1").arg(avErr(wr)));
            break;
        }
    }
}
