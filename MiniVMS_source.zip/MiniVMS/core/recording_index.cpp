#include "core/recording_index.h"

#include <QDateTime>
#include <QFileInfo>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QUuid>

namespace {

SegmentInfo rowToSegment(const QSqlQuery &q)
{
    SegmentInfo s;
    s.id = q.value(0).toLongLong();
    s.cameraId = q.value(1).toString();
    s.path = q.value(2).toString();
    s.startMs = q.value(3).toLongLong();
    s.endMs = q.value(4).isNull() ? 0 : q.value(4).toLongLong();
    s.sizeBytes = q.value(5).toLongLong();
    return s;
}

const char *kSelectColumns = "SELECT id, camera_id, path, start_ms, end_ms, size_bytes FROM segments ";

} // namespace

RecordingIndex::~RecordingIndex() { close(); }

bool RecordingIndex::open(const QString &dbPath)
{
    close();
    m_conn = QStringLiteral("vms_idx_") + QUuid::createUuid().toString(QUuid::Id128);

    QSqlDatabase db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), m_conn);
    db.setDatabaseName(dbPath);
    if (!db.open()) {
        m_lastError = db.lastError().text();
        return false;
    }

    QSqlQuery q(db);
    q.exec(QStringLiteral("PRAGMA journal_mode=WAL"));
    q.exec(QStringLiteral("PRAGMA synchronous=NORMAL"));
    q.exec(QStringLiteral("PRAGMA busy_timeout=5000"));

    const bool ok =
        q.exec(QStringLiteral(
            "CREATE TABLE IF NOT EXISTS segments ("
            " id         INTEGER PRIMARY KEY AUTOINCREMENT,"
            " camera_id  TEXT    NOT NULL,"
            " path       TEXT    NOT NULL,"
            " start_ms   INTEGER NOT NULL,"
            " end_ms     INTEGER,"
            " size_bytes INTEGER NOT NULL DEFAULT 0)"))
        && q.exec(QStringLiteral(
            "CREATE INDEX IF NOT EXISTS idx_segments_cam_time "
            "ON segments(camera_id, start_ms)"));
    if (!ok)
        m_lastError = q.lastError().text();
    return ok;
}

void RecordingIndex::close()
{
    if (m_conn.isEmpty())
        return;
    {
        QSqlDatabase db = QSqlDatabase::database(m_conn, false);
        if (db.isOpen())
            db.close();
    }
    QSqlDatabase::removeDatabase(m_conn);
    m_conn.clear();
}

qint64 RecordingIndex::beginSegment(const QString &cameraId, const QString &path, qint64 startMs)
{
    QSqlQuery q(QSqlDatabase::database(m_conn));
    q.prepare(QStringLiteral("INSERT INTO segments(camera_id, path, start_ms) VALUES(?, ?, ?)"));
    q.addBindValue(cameraId);
    q.addBindValue(path);
    q.addBindValue(startMs);
    if (!q.exec()) {
        m_lastError = q.lastError().text();
        return -1;
    }
    return q.lastInsertId().toLongLong();
}

bool RecordingIndex::endSegment(qint64 id, qint64 endMs, qint64 sizeBytes)
{
    if (id < 0)
        return false;
    QSqlQuery q(QSqlDatabase::database(m_conn));
    q.prepare(QStringLiteral("UPDATE segments SET end_ms = ?, size_bytes = ? WHERE id = ?"));
    q.addBindValue(endMs);
    q.addBindValue(sizeBytes);
    q.addBindValue(id);
    if (!q.exec()) {
        m_lastError = q.lastError().text();
        return false;
    }
    return true;
}

void RecordingIndex::closeDanglingSegments(const QString &cameraId)
{
    struct Row { qint64 id; QString path; qint64 startMs; };
    QList<Row> rows;
    {
        QSqlQuery q(QSqlDatabase::database(m_conn));
        q.prepare(QStringLiteral(
            "SELECT id, path, start_ms FROM segments WHERE camera_id = ? AND end_ms IS NULL"));
        q.addBindValue(cameraId);
        if (!q.exec()) {
            m_lastError = q.lastError().text();
            return;
        }
        while (q.next())
            rows.append({q.value(0).toLongLong(), q.value(1).toString(), q.value(2).toLongLong()});
    }

    for (const Row &r : rows) {
        const QFileInfo fi(r.path);
        QSqlQuery q(QSqlDatabase::database(m_conn));
        if (fi.exists() && fi.size() > 0) {
            const qint64 endMs = qMax(fi.lastModified().toMSecsSinceEpoch(), r.startMs);
            q.prepare(QStringLiteral("UPDATE segments SET end_ms = ?, size_bytes = ? WHERE id = ?"));
            q.addBindValue(endMs);
            q.addBindValue(fi.size());
            q.addBindValue(r.id);
        } else {
            q.prepare(QStringLiteral("DELETE FROM segments WHERE id = ?"));
            q.addBindValue(r.id);
        }
        q.exec();
    }
}

QList<SegmentInfo> RecordingIndex::segmentsInRange(const QString &cameraId, qint64 fromMs, qint64 toMs)
{
    QList<SegmentInfo> out;
    QSqlQuery q(QSqlDatabase::database(m_conn));
    q.prepare(QString::fromLatin1(kSelectColumns) +
              QStringLiteral("WHERE camera_id = ? AND start_ms < ? "
                             "AND (end_ms IS NULL OR end_ms > ?) ORDER BY start_ms"));
    q.addBindValue(cameraId);
    q.addBindValue(toMs);
    q.addBindValue(fromMs);
    if (!q.exec()) {
        m_lastError = q.lastError().text();
        return out;
    }
    while (q.next())
        out.append(rowToSegment(q));
    return out;
}

SegmentInfo RecordingIndex::segmentAt(const QString &cameraId, qint64 ms)
{
    QSqlQuery q(QSqlDatabase::database(m_conn));
    q.prepare(QString::fromLatin1(kSelectColumns) +
              QStringLiteral("WHERE camera_id = ? AND start_ms <= ? "
                             "ORDER BY start_ms DESC LIMIT 1"));
    q.addBindValue(cameraId);
    q.addBindValue(ms);
    if (q.exec() && q.next()) {
        const SegmentInfo s = rowToSegment(q);
        if (s.endMs == 0 || ms <= s.endMs)
            return s;
    }
    return {};
}
