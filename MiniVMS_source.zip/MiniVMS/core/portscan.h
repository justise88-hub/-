#pragma once

#include <QObject>
#include <QString>

// Быстрая проверка, у каких адресов диапазона открыт TCP-порт (например, RTSP 554).
class PortScanner : public QObject {
    Q_OBJECT
public:
    explicit PortScanner(QObject *parent = nullptr);
    void start(quint32 firstIp, quint32 lastIp, quint16 port, int concurrency = 64, int timeoutMs = 800);
    void stop();

signals:
    void found(const QString &ip);
    void progress(int done, int total);
    void finished();

private:
    void pump();

    qint64 m_next = 0;
    qint64 m_last = -1;
    quint16 m_port = 554;
    int m_conc = 64;
    int m_timeout = 800;
    int m_active = 0;
    int m_done = 0;
    int m_total = 0;
    int m_gen = 0;
    bool m_running = false;
};
