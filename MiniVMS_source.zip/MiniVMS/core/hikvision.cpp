#include "core/hikvision.h"

#include <QAuthenticator>
#include <QHostAddress>
#include <QMap>
#include <QNetworkAccessManager>
#include <QNetworkInterface>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QTimer>
#include <QUdpSocket>
#include <QUuid>
#include <QXmlStreamReader>

#include <functional>

namespace {

bool isName(const QXmlStreamReader &x, const char *n)
{
    return x.name() == QLatin1String(n);
}

struct HttpReply {
    bool ok = false;
    QByteArray body;
    QString error;
};

// GET с HTTP Digest: логин и пароль берутся из свойств ответа (разные для каждого устройства)
void httpGet(QNetworkAccessManager *nam, QObject *ctx, const HikRequest &req, const QString &path,
             std::function<void(const HttpReply &)> cb)
{
    QUrl url;
    url.setScheme(QStringLiteral("http"));
    url.setHost(req.address);
    url.setPort(req.httpPort);
    url.setPath(path);

    QNetworkRequest nr(url);
    nr.setTransferTimeout(5000);
    QNetworkReply *reply = nam->get(nr);
    reply->setProperty("hik_user", req.user);
    reply->setProperty("hik_pass", req.password);

    QObject::connect(reply, &QNetworkReply::finished, ctx, [reply, cb] {
        HttpReply h;
        h.body = reply->readAll();
        h.ok = reply->error() == QNetworkReply::NoError;
        if (!h.ok) {
            switch (reply->error()) {
            case QNetworkReply::AuthenticationRequiredError:
                h.error = QStringLiteral("Неверный логин или пароль (или устройство не активировано)");
                break;
            case QNetworkReply::TimeoutError:
                h.error = QStringLiteral("Не отвечает (таймаут)");
                break;
            case QNetworkReply::ConnectionRefusedError:
                h.error = QStringLiteral("Порт закрыт");
                break;
            case QNetworkReply::ContentNotFoundError:
                h.error = QStringLiteral("Это не Hikvision/HiWatch (нет ISAPI)");
                break;
            default:
                h.error = reply->errorString();
            }
        }
        reply->deleteLater();
        cb(h);
    });
}

void parseDeviceInfo(const QByteArray &xml, HikDevice *dev)
{
    QXmlStreamReader x(xml);
    while (!x.atEnd()) {
        x.readNext();
        if (!x.isStartElement())
            continue;
        if (isName(x, "deviceName")) dev->name = x.readElementText().trimmed();
        else if (isName(x, "model")) dev->model = x.readElementText().trimmed();
        else if (isName(x, "serialNumber")) dev->serial = x.readElementText().trimmed();
        else if (isName(x, "deviceType")) dev->type = x.readElementText().trimmed();
    }
}

// Каналы из /ISAPI/Streaming/channels: id 101 и 102 — канал 1, 201 и 202 — канал 2 и т. д.
QList<HikChannel> parseChannels(const QByteArray &xml)
{
    QMap<int, QString> found;
    QXmlStreamReader x(xml);
    bool inCh = false;
    int id = 0;
    QString name;
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement()) {
            if (isName(x, "StreamingChannel")) {
                inCh = true;
                id = 0;
                name.clear();
            } else if (inCh && id == 0 && isName(x, "id")) {
                id = x.readElementText().toInt();
            } else if (inCh && name.isEmpty() && isName(x, "channelName")) {
                name = x.readElementText().trimmed();
            }
        } else if (x.isEndElement() && isName(x, "StreamingChannel")) {
            if (id >= 101 && (id % 100 == 1 || id % 100 == 2)) {
                const int n = id / 100;
                if (!found.contains(n) || found.value(n).isEmpty())
                    found[n] = name;
            }
            inCh = false;
        }
    }
    QList<HikChannel> out;
    for (auto it = found.cbegin(); it != found.cend(); ++it) {
        HikChannel c;
        c.number = it.key();
        c.name = it.value();
        out.append(c);
    }
    return out;
}

} // namespace

// ===========================================================================
// HikDiscovery (SADP)
// ===========================================================================

HikDiscovery::HikDiscovery(QObject *parent) : QObject(parent)
{
    m_socket = new QUdpSocket(this);
    connect(m_socket, &QUdpSocket::readyRead, this, &HikDiscovery::onReadyRead);

    m_timer = new QTimer(this);
    m_timer->setSingleShot(true);
    connect(m_timer, &QTimer::timeout, this, [this] {
        m_running = false;
        emit finished();
    });
}

void HikDiscovery::start(int timeoutMs)
{
    stop();
    m_seen.clear();

    // Устройства отвечают на multicast-группу, поэтому слушаем порт 37020 и входим в группу
    if (m_socket->state() != QAbstractSocket::BoundState
        && !m_socket->bind(QHostAddress::AnyIPv4, 37020,
                           QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint)) {
        emit finished();
        return;
    }
    const QHostAddress group(QStringLiteral("239.255.255.250"));
    for (const QNetworkInterface &ni : QNetworkInterface::allInterfaces()) {
        const auto fl = ni.flags();
        if ((fl & QNetworkInterface::IsUp) && (fl & QNetworkInterface::IsRunning)
            && (fl & QNetworkInterface::CanMulticast) && !(fl & QNetworkInterface::IsLoopBack))
            m_socket->joinMulticastGroup(group, ni);
    }
    m_socket->setSocketOption(QAbstractSocket::MulticastTtlOption, 4);

    m_running = true;
    sendProbes();
    QTimer::singleShot(1000, this, [this] { if (m_running) sendProbes(); });
    m_timer->start(timeoutMs);
}

void HikDiscovery::stop()
{
    m_running = false;
    m_timer->stop();
}

void HikDiscovery::sendProbes()
{
    const QByteArray probe =
        QByteArray("<?xml version=\"1.0\" encoding=\"utf-8\"?><Probe><Uuid>")
        + QUuid::createUuid().toString(QUuid::WithoutBraces).toUpper().toUtf8()
        + QByteArray("</Uuid><Types>inquiry</Types></Probe>");

    const QHostAddress group(QStringLiteral("239.255.255.250"));
    for (const QNetworkInterface &ni : QNetworkInterface::allInterfaces()) {
        const auto fl = ni.flags();
        if (!(fl & QNetworkInterface::IsUp) || !(fl & QNetworkInterface::IsRunning)
            || (fl & QNetworkInterface::IsLoopBack) || !(fl & QNetworkInterface::CanMulticast))
            continue;
        m_socket->setMulticastInterface(ni);
        m_socket->writeDatagram(probe, group, 37020);
    }
}

void HikDiscovery::onReadyRead()
{
    while (m_socket->hasPendingDatagrams()) {
        QByteArray data;
        data.resize(int(m_socket->pendingDatagramSize()));
        m_socket->readDatagram(data.data(), data.size());
        if (!m_running || !data.contains("ProbeMatch"))   // свои же запросы пропускаем
            continue;

        HikDevice dev;
        QXmlStreamReader x(data);
        while (!x.atEnd()) {
            x.readNext();
            if (!x.isStartElement())
                continue;
            if (isName(x, "IPv4Address")) dev.address = x.readElementText().trimmed();
            else if (isName(x, "HttpPort")) dev.httpPort = quint16(x.readElementText().toUInt());
            else if (isName(x, "DeviceDescription")) dev.model = x.readElementText().trimmed();
            else if (isName(x, "DeviceSN")) dev.serial = x.readElementText().trimmed();
            else if (isName(x, "Activated")) dev.activated = x.readElementText().trimmed() != QLatin1String("false");
        }
        if (dev.httpPort == 0)
            dev.httpPort = 80;
        if (dev.address.isEmpty() || m_seen.contains(dev.address))
            continue;
        m_seen.insert(dev.address);
        emit deviceFound(dev);
    }
}

// ===========================================================================
// HikResolver (ISAPI)
// ===========================================================================

HikResolver::HikResolver(QObject *parent) : QObject(parent)
{
    m_nam = new QNetworkAccessManager(this);
    connect(m_nam, &QNetworkAccessManager::authenticationRequired, this,
            [](QNetworkReply *reply, QAuthenticator *auth) {
                auth->setUser(reply->property("hik_user").toString());
                auth->setPassword(reply->property("hik_pass").toString());
            });
}

void HikResolver::start(const QList<HikRequest> &requests, int concurrency)
{
    ++m_gen;
    m_requests = requests;
    m_next = 0;
    m_done = 0;
    m_active = 0;
    m_conc = qMax(1, concurrency);
    m_running = true;
    if (requests.isEmpty()) {
        m_running = false;
        emit finished();
        return;
    }
    pump();
}

void HikResolver::cancel()
{
    m_running = false;
    ++m_gen;
}

void HikResolver::pump()
{
    while (m_running && m_active < m_conc && m_next < m_requests.size()) {
        ++m_active;
        runJob(m_next++);
    }
}

void HikResolver::jobDone(int idx, const HikResult &r, int gen)
{
    if (gen != m_gen)
        return;
    --m_active;
    ++m_done;
    emit resolved(idx, r);
    emit progress(m_done, int(m_requests.size()));
    if (m_done >= m_requests.size()) {
        m_running = false;
        emit finished();
    } else {
        pump();
    }
}

void HikResolver::runJob(int idx)
{
    const HikRequest req = m_requests.at(idx);
    const int gen = m_gen;

    auto fail = [this, idx, gen](const QString &msg) {
        HikResult r;
        r.error = msg;
        jobDone(idx, r, gen);
    };

    // 1. Тип устройства и модель
    httpGet(m_nam, this, req, QStringLiteral("/ISAPI/System/deviceInfo"), [=](const HttpReply &r1) {
        if (gen != m_gen)
            return;
        if (!r1.ok) {
            fail(r1.error);
            return;
        }
        HikDevice dev;
        dev.address = req.address;
        dev.httpPort = req.httpPort;
        parseDeviceInfo(r1.body, &dev);
        if (dev.model.isEmpty() && dev.name.isEmpty()) {
            fail(QStringLiteral("Ответ не похож на Hikvision/HiWatch"));
            return;
        }

        // 2. Каналы (у регистратора — все, у камеры — один)
        httpGet(m_nam, this, req, QStringLiteral("/ISAPI/Streaming/channels"), [=](const HttpReply &r2) {
            if (gen != m_gen)
                return;
            HikDevice d = dev;
            if (r2.ok)
                d.channels = parseChannels(r2.body);
            if (d.channels.isEmpty()) {
                const int n = d.isRecorder() ? req.fallbackChannels : 1;
                for (int i = 1; i <= n; ++i) {
                    HikChannel c;
                    c.number = i;
                    d.channels.append(c);
                }
            }
            if (d.channels.isEmpty()) {
                fail(QStringLiteral("Не удалось получить каналы регистратора: укажите их число вручную"));
                return;
            }
            HikResult res;
            res.ok = true;
            res.device = d;
            jobDone(idx, res, gen);
        });
    });
}
