#pragma once

#include <QList>
#include <QObject>
#include <QSet>
#include <QString>

class QNetworkAccessManager;
class QTimer;
class QUdpSocket;

// Найденное ONVIF-устройство.
struct OnvifDevice {
    QString address;    // IPv4 камеры
    QString xaddr;      // http://ip:port/onvif/device_service
    QString name;       // из scopes (если камера сообщила)
    QString hardware;   // модель из scopes
};

struct OnvifRequest {
    QString xaddr;
    QString user;
    QString password;
};

// Результат опроса камеры: адреса потоков уже с логином и паролем.
struct OnvifStreams {
    bool ok = false;
    QString error;
    QString mainUrl;   // профиль с максимальным разрешением (для записи)
    QString subUrl;    // профиль с минимальным разрешением (для мозаики), может быть пустым
};

// ---------------------------------------------------------------------------
// Поиск по WS-Discovery (multicast 239.255.255.250:3702).
// Работает только в той же подсети (L2), что и компьютер.
class OnvifDiscovery : public QObject {
    Q_OBJECT
public:
    explicit OnvifDiscovery(QObject *parent = nullptr);
    void start(int timeoutMs = 4000);
    void stop();

signals:
    void deviceFound(const OnvifDevice &dev);
    void finished();

private:
    void sendProbes();
    void onReadyRead();

    QUdpSocket *m_socket = nullptr;
    QTimer *m_timer = nullptr;
    QSet<QString> m_seen;
    bool m_running = false;
};

// ---------------------------------------------------------------------------
// Сканирование диапазона IP: на каждый адрес уходит GetSystemDateAndTime
// (разрешён без авторизации). Находит камеры в других подсетях и VLAN,
// куда multicast не доходит.
class OnvifScanner : public QObject {
    Q_OBJECT
public:
    explicit OnvifScanner(QObject *parent = nullptr);
    void start(quint32 firstIp, quint32 lastIp, quint16 port = 80, int concurrency = 64);
    void stop();

signals:
    void deviceFound(const OnvifDevice &dev);
    void progress(int done, int total);
    void finished();

private:
    void pump();

    QNetworkAccessManager *m_nam = nullptr;
    qint64 m_next = 0;
    qint64 m_last = -1;
    quint16 m_port = 80;
    int m_conc = 64;
    int m_active = 0;
    int m_done = 0;
    int m_total = 0;
    int m_gen = 0;
    bool m_running = false;
};

// ---------------------------------------------------------------------------
// Пакетное получение RTSP-адресов: для каждой камеры по цепочке
// GetSystemDateAndTime -> GetCapabilities -> GetProfiles -> GetStreamUri.
// Одновременно опрашивается не более `concurrency` камер.
class OnvifResolver : public QObject {
    Q_OBJECT
public:
    explicit OnvifResolver(QObject *parent = nullptr);
    void start(const QList<OnvifRequest> &requests, int concurrency = 8);
    void cancel();

signals:
    void resolved(int index, const OnvifStreams &streams);   // index — позиция в requests
    void progress(int done, int total);
    void finished();

private:
    void pump();
    void runJob(int idx);
    void jobDone(int idx, const OnvifStreams &s, int gen);

    QNetworkAccessManager *m_nam = nullptr;
    QList<OnvifRequest> m_requests;
    int m_next = 0;
    int m_done = 0;
    int m_active = 0;
    int m_conc = 8;
    int m_gen = 0;
    bool m_running = false;
};
