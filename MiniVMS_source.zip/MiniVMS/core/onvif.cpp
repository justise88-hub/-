#include "core/onvif.h"

#include <QCryptographicHash>
#include <QDateTime>
#include <QHostAddress>
#include <QNetworkAccessManager>
#include <QNetworkInterface>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRandomGenerator>
#include <QStringList>
#include <QTimer>
#include <QUdpSocket>
#include <QUrl>
#include <QUuid>
#include <QXmlStreamReader>

#include <algorithm>
#include <functional>

namespace {

constexpr int kTimeoutMs = 6000;

bool isName(const QXmlStreamReader &x, const char *n)
{
    return x.name() == QLatin1String(n);
}

// ---------- SOAP ----------

// Конверт SOAP 1.2; при заданном логине добавляется WS-Security UsernameToken (PasswordDigest).
// offsetSecs — разница часов камеры и компьютера: без неё многие камеры отклоняют подпись.
QByteArray soapEnvelope(const QByteArray &body, const QString &user = QString(),
                        const QString &pass = QString(), qint64 offsetSecs = 0)
{
    QByteArray header;
    if (!user.isEmpty()) {
        QByteArray nonce(16, '\0');
        for (char &c : nonce)
            c = char(QRandomGenerator::global()->bounded(256));
        const QByteArray created =
            QDateTime::currentDateTimeUtc().addSecs(offsetSecs).toString(Qt::ISODate).toUtf8();
        const QByteArray digest =
            QCryptographicHash::hash(nonce + created + pass.toUtf8(), QCryptographicHash::Sha1).toBase64();

        header = QByteArray(
            "<s:Header><wsse:Security s:mustUnderstand=\"1\" "
            "xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" "
            "xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"
            "<wsse:UsernameToken><wsse:Username>")
            + user.toHtmlEscaped().toUtf8()
            + QByteArray("</wsse:Username><wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/"
                         "oasis-200401-wss-username-token-profile-1.0#PasswordDigest\">")
            + digest
            + QByteArray("</wsse:Password><wsse:Nonce EncodingType=\"http://docs.oasis-open.org/wss/2004/01/"
                         "oasis-200401-wss-soap-message-security-1.0#Base64Binary\">")
            + nonce.toBase64()
            + QByteArray("</wsse:Nonce><wsu:Created>") + created
            + QByteArray("</wsu:Created></wsse:UsernameToken></wsse:Security></s:Header>");
    }

    return QByteArray(
               "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
               "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" "
               "xmlns:tds=\"http://www.onvif.org/ver10/device/wsdl\" "
               "xmlns:trt=\"http://www.onvif.org/ver10/media/wsdl\" "
               "xmlns:tt=\"http://www.onvif.org/ver10/schema\">")
           + header + QByteArray("<s:Body>") + body + QByteArray("</s:Body></s:Envelope>");
}

struct SoapReply {
    bool ok = false;
    QByteArray body;
    QString error;
};

QString faultText(const QByteArray &xml)
{
    QXmlStreamReader x(xml);
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement() && (isName(x, "Text") || isName(x, "faultstring")))
            return x.readElementText().trimmed();
    }
    return QString();
}

void postSoap(QNetworkAccessManager *nam, QObject *ctx, const QUrl &url, const QByteArray &body,
              int timeoutMs, std::function<void(const SoapReply &)> cb)
{
    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/soap+xml; charset=utf-8"));
    req.setTransferTimeout(timeoutMs);
    QNetworkReply *reply = nam->post(req, body);

    QObject::connect(reply, &QNetworkReply::finished, ctx, [reply, cb] {
        SoapReply r;
        r.body = reply->readAll();
        r.ok = reply->error() == QNetworkReply::NoError;
        if (!r.ok) {
            const QString fault = faultText(r.body);
            if (reply->error() == QNetworkReply::AuthenticationRequiredError
                || fault.contains(QLatin1String("authorized"), Qt::CaseInsensitive))
                r.error = QStringLiteral("Неверный логин или пароль");
            else if (reply->error() == QNetworkReply::TimeoutError)
                r.error = QStringLiteral("Камера не отвечает (таймаут)");
            else
                r.error = fault.isEmpty() ? reply->errorString() : fault;
        }
        reply->deleteLater();
        cb(r);
    });
}

// ---------- разбор ответов ----------

QString firstText(const QByteArray &xml, const char *name)
{
    QXmlStreamReader x(xml);
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement() && isName(x, name))
            return x.readElementText().trimmed();
    }
    return QString();
}

// Разница «время камеры − наше UTC» в секундах
qint64 parseTimeOffset(const QByteArray &xml)
{
    QXmlStreamReader x(xml);
    bool inUtc = false;
    int h = -1, mi = -1, s = -1, y = -1, mo = -1, d = -1;
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement()) {
            if (isName(x, "UTCDateTime")) {
                inUtc = true;
            } else if (inUtc) {
                if (isName(x, "Hour")) h = x.readElementText().toInt();
                else if (isName(x, "Minute")) mi = x.readElementText().toInt();
                else if (isName(x, "Second")) s = x.readElementText().toInt();
                else if (isName(x, "Year")) y = x.readElementText().toInt();
                else if (isName(x, "Month")) mo = x.readElementText().toInt();
                else if (isName(x, "Day")) d = x.readElementText().toInt();
            }
        } else if (x.isEndElement() && isName(x, "UTCDateTime")) {
            break;
        }
    }
    if (h < 0 || mi < 0 || s < 0 || y < 0 || mo < 0 || d < 0)
        return 0;
    QDateTime cam(QDate(y, mo, d), QTime(h, mi, s));
    cam.setTimeSpec(Qt::UTC);
    if (!cam.isValid())
        return 0;
    return QDateTime::currentDateTimeUtc().secsTo(cam);
}

QString mediaXAddr(const QByteArray &xml)
{
    QXmlStreamReader x(xml);
    bool inMedia = false;
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement()) {
            if (isName(x, "Media"))
                inMedia = true;
            else if (inMedia && isName(x, "XAddr"))
                return x.readElementText().trimmed();
        }
    }
    return QString();
}

struct Profile {
    QString token;
    int w = 0;
    int h = 0;
    qint64 area() const { return qint64(w) * h; }
};

QList<Profile> parseProfiles(const QByteArray &xml)
{
    QList<Profile> out;
    QXmlStreamReader x(xml);
    bool inEnc = false, inRes = false;
    while (!x.atEnd()) {
        x.readNext();
        if (x.isStartElement()) {
            if (isName(x, "Profiles")) {
                Profile p;
                p.token = x.attributes().value(QLatin1String("token")).toString();
                out.append(p);
            } else if (isName(x, "VideoEncoderConfiguration")) {
                inEnc = true;
            } else if (inEnc && isName(x, "Resolution")) {
                inRes = true;
            } else if (inEnc && inRes && !out.isEmpty()) {
                if (isName(x, "Width")) out.last().w = x.readElementText().toInt();
                else if (isName(x, "Height")) out.last().h = x.readElementText().toInt();
            }
        } else if (x.isEndElement()) {
            if (isName(x, "Resolution")) inRes = false;
            else if (isName(x, "VideoEncoderConfiguration")) inEnc = false;
        }
    }
    return out;
}

QByteArray streamUriBody(const QString &token)
{
    return QByteArray("<trt:GetStreamUri><trt:StreamSetup><tt:Stream>RTP-Unicast</tt:Stream>"
                      "<tt:Transport><tt:Protocol>RTSP</tt:Protocol></tt:Transport></trt:StreamSetup>"
                      "<trt:ProfileToken>")
           + token.toHtmlEscaped().toUtf8() + QByteArray("</trt:ProfileToken></trt:GetStreamUri>");
}

QString withCredentials(const QString &uri, const OnvifRequest &req)
{
    QUrl u(uri);
    if (!u.isValid())
        return uri;
    if (u.userName().isEmpty() && !req.user.isEmpty()) {
        u.setUserName(req.user);
        u.setPassword(req.password);
    }
    return u.toString(QUrl::FullyEncoded);
}

OnvifDevice parseScopes(OnvifDevice dev, const QString &scopes)
{
    for (const QString &tok : scopes.split(QLatin1Char(' '), Qt::SkipEmptyParts)) {
        int p = tok.indexOf(QLatin1String("/name/"));
        if (p >= 0) {
            dev.name = QUrl::fromPercentEncoding(tok.mid(p + 6).toUtf8());
            continue;
        }
        p = tok.indexOf(QLatin1String("/hardware/"));
        if (p >= 0)
            dev.hardware = QUrl::fromPercentEncoding(tok.mid(p + 10).toUtf8());
    }
    return dev;
}

} // namespace

// ===========================================================================
// OnvifDiscovery
// ===========================================================================

OnvifDiscovery::OnvifDiscovery(QObject *parent) : QObject(parent)
{
    m_socket = new QUdpSocket(this);
    connect(m_socket, &QUdpSocket::readyRead, this, &OnvifDiscovery::onReadyRead);

    m_timer = new QTimer(this);
    m_timer->setSingleShot(true);
    connect(m_timer, &QTimer::timeout, this, [this] {
        m_running = false;
        emit finished();
    });
}

void OnvifDiscovery::start(int timeoutMs)
{
    stop();
    m_seen.clear();

    if (m_socket->state() != QAbstractSocket::BoundState
        && !m_socket->bind(QHostAddress::AnyIPv4, 0)) {
        emit finished();
        return;
    }
    m_socket->setSocketOption(QAbstractSocket::MulticastTtlOption, 4);

    m_running = true;
    sendProbes();
    QTimer::singleShot(1000, this, [this] { if (m_running) sendProbes(); });   // повтор для надёжности
    m_timer->start(timeoutMs);
}

void OnvifDiscovery::stop()
{
    m_running = false;
    m_timer->stop();
}

void OnvifDiscovery::sendProbes()
{
    const QByteArray probe =
        QByteArray(
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            "<e:Envelope xmlns:e=\"http://www.w3.org/2003/05/soap-envelope\" "
            "xmlns:w=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" "
            "xmlns:d=\"http://schemas.xmlsoap.org/ws/2005/04/discovery\" "
            "xmlns:dn=\"http://www.onvif.org/ver10/network/wsdl\"><e:Header>"
            "<w:MessageID>uuid:")
        + QUuid::createUuid().toString(QUuid::WithoutBraces).toUtf8()
        + QByteArray(
            "</w:MessageID><w:To e:mustUnderstand=\"true\">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>"
            "<w:Action e:mustUnderstand=\"true\">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>"
            "</e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body>"
            "</e:Envelope>");

    const QHostAddress group(QStringLiteral("239.255.255.250"));
    for (const QNetworkInterface &ni : QNetworkInterface::allInterfaces()) {
        const auto fl = ni.flags();
        if (!(fl & QNetworkInterface::IsUp) || !(fl & QNetworkInterface::IsRunning)
            || (fl & QNetworkInterface::IsLoopBack) || !(fl & QNetworkInterface::CanMulticast))
            continue;
        m_socket->setMulticastInterface(ni);   // шлём через каждый сетевой адаптер
        m_socket->writeDatagram(probe, group, 3702);
    }
}

void OnvifDiscovery::onReadyRead()
{
    while (m_socket->hasPendingDatagrams()) {
        QByteArray data;
        data.resize(int(m_socket->pendingDatagramSize()));
        m_socket->readDatagram(data.data(), data.size());
        if (!m_running)
            continue;

        QString xaddrs, scopes;
        QXmlStreamReader x(data);
        while (!x.atEnd()) {
            x.readNext();
            if (x.isStartElement()) {
                if (isName(x, "XAddrs")) xaddrs = x.readElementText();
                else if (isName(x, "Scopes")) scopes = x.readElementText();
            }
        }

        OnvifDevice dev;
        for (const QString &u : xaddrs.split(QLatin1Char(' '), Qt::SkipEmptyParts)) {
            const QUrl url(u);
            if (url.scheme() == QLatin1String("http") && !url.host().contains(QLatin1Char(':'))) {
                dev.xaddr = u;
                dev.address = url.host();
                break;
            }
        }
        if (dev.xaddr.isEmpty() || m_seen.contains(dev.address))
            continue;
        m_seen.insert(dev.address);
        emit deviceFound(parseScopes(dev, scopes));
    }
}

// ===========================================================================
// OnvifScanner
// ===========================================================================

OnvifScanner::OnvifScanner(QObject *parent) : QObject(parent)
{
    m_nam = new QNetworkAccessManager(this);
}

void OnvifScanner::start(quint32 firstIp, quint32 lastIp, quint16 port, int concurrency)
{
    stop();
    ++m_gen;
    m_next = firstIp;
    m_last = lastIp;
    m_port = port;
    m_conc = qMax(1, concurrency);
    m_total = int(m_last - m_next + 1);
    m_done = 0;
    m_active = 0;
    m_running = true;
    pump();
}

void OnvifScanner::stop()
{
    m_running = false;
    ++m_gen;
}

void OnvifScanner::pump()
{
    while (m_running && m_active < m_conc && m_next <= m_last) {
        const QString host = QHostAddress(quint32(m_next++)).toString();
        const QUrl url(QStringLiteral("http://%1:%2/onvif/device_service").arg(host).arg(m_port));
        const int gen = m_gen;
        ++m_active;

        postSoap(m_nam, this, url, soapEnvelope("<tds:GetSystemDateAndTime/>"), 1500,
                 [this, gen, host, url](const SoapReply &r) {
            if (gen != m_gen)
                return;
            --m_active;
            ++m_done;
            // даже SOAP-ошибка с HTTP 4xx означает, что по адресу отвечает ONVIF-устройство
            if (r.body.contains("Envelope")) {
                OnvifDevice d;
                d.address = host;
                d.xaddr = url.toString();
                emit deviceFound(d);
            }
            emit progress(m_done, m_total);
            pump();
        });
    }
    if (m_running && m_next > m_last && m_active == 0) {
        m_running = false;
        emit finished();
    }
}

// ===========================================================================
// OnvifResolver
// ===========================================================================

OnvifResolver::OnvifResolver(QObject *parent) : QObject(parent)
{
    m_nam = new QNetworkAccessManager(this);
}

void OnvifResolver::start(const QList<OnvifRequest> &requests, int concurrency)
{
    ++m_gen;
    m_requests = requests;
    m_next = 0;
    m_done = 0;
    m_active = 0;
    m_conc = qMax(1, concurrency);
    m_running = true;
    if (requests.isEmpty()) {
        m_running = false;
        emit finished();
        return;
    }
    pump();
}

void OnvifResolver::cancel()
{
    m_running = false;
    ++m_gen;
}

void OnvifResolver::pump()
{
    while (m_running && m_active < m_conc && m_next < m_requests.size()) {
        ++m_active;
        runJob(m_next++);
    }
}

void OnvifResolver::jobDone(int idx, const OnvifStreams &s, int gen)
{
    if (gen != m_gen)
        return;
    --m_active;
    ++m_done;
    emit resolved(idx, s);
    emit progress(m_done, int(m_requests.size()));
    if (m_done >= m_requests.size()) {
        m_running = false;
        emit finished();
    } else {
        pump();
    }
}

void OnvifResolver::runJob(int idx)
{
    const OnvifRequest req = m_requests.at(idx);
    const int gen = m_gen;
    const QUrl devUrl(req.xaddr);

    auto fail = [this, idx, gen](const QString &msg) {
        OnvifStreams s;
        s.error = msg;
        jobDone(idx, s, gen);
    };

    // 1. Время камеры (без авторизации) — нужно для подписи WS-Security
    postSoap(m_nam, this, devUrl, soapEnvelope("<tds:GetSystemDateAndTime/>"), kTimeoutMs,
             [=](const SoapReply &r1) {
        if (gen != m_gen)
            return;
        const qint64 offset = r1.ok ? parseTimeOffset(r1.body) : 0;

        // 2. Адрес media-сервиса
        postSoap(m_nam, this, devUrl,
                 soapEnvelope("<tds:GetCapabilities><tds:Category>Media</tds:Category></tds:GetCapabilities>",
                              req.user, req.password, offset),
                 kTimeoutMs, [=](const SoapReply &r2) {
            if (gen != m_gen)
                return;
            if (!r2.ok) {
                fail(r2.error);
                return;
            }
            QUrl mediaUrl(mediaXAddr(r2.body));
            if (!mediaUrl.isValid() || mediaUrl.host().isEmpty()) {
                fail(QStringLiteral("Камера не вернула адрес media-сервиса (проверьте логин и пароль)"));
                return;
            }
            mediaUrl.setHost(devUrl.host());   // камеры за NAT иногда отдают внутренний адрес

            // 3. Профили видео
            postSoap(m_nam, this, mediaUrl,
                     soapEnvelope("<trt:GetProfiles/>", req.user, req.password, offset),
                     kTimeoutMs, [=](const SoapReply &r3) {
                if (gen != m_gen)
                    return;
                if (!r3.ok) {
                    fail(r3.error);
                    return;
                }
                QList<Profile> valid;
                const QList<Profile> all = parseProfiles(r3.body);
                for (const Profile &p : all)
                    if (!p.token.isEmpty() && p.area() > 0)
                        valid.append(p);
                if (valid.isEmpty() && !all.isEmpty() && !all.first().token.isEmpty())
                    valid.append(all.first());   // разрешение неизвестно — берём первый профиль
                if (valid.isEmpty()) {
                    fail(QStringLiteral("У камеры нет видеопрофилей"));
                    return;
                }

                const auto byArea = [](const Profile &a, const Profile &b) { return a.area() < b.area(); };
                const Profile mainP = *std::max_element(valid.begin(), valid.end(), byArea);
                Profile subP = *std::min_element(valid.begin(), valid.end(), byArea);
                if (subP.token == mainP.token)
                    subP.token.clear();   // профиль всего один

                // 4. RTSP-адрес основного потока
                postSoap(m_nam, this, mediaUrl,
                         soapEnvelope(streamUriBody(mainP.token), req.user, req.password, offset),
                         kTimeoutMs, [=](const SoapReply &r4) {
                    if (gen != m_gen)
                        return;
                    if (!r4.ok) {
                        fail(r4.error);
                        return;
                    }
                    const QString mainUri = firstText(r4.body, "Uri");
                    if (mainUri.isEmpty()) {
                        fail(QStringLiteral("Камера не вернула RTSP-адрес"));
                        return;
                    }
                    OnvifStreams s;
                    s.ok = true;
                    s.mainUrl = withCredentials(mainUri, req);
                    if (subP.token.isEmpty()) {
                        jobDone(idx, s, gen);
                        return;
                    }

                    // 5. RTSP-адрес дополнительного потока (для мозаики)
                    postSoap(m_nam, this, mediaUrl,
                             soapEnvelope(streamUriBody(subP.token), req.user, req.password, offset),
                             kTimeoutMs, [=](const SoapReply &r5) {
                        if (gen != m_gen)
                            return;
                        OnvifStreams out = s;
                        if (r5.ok) {
                            const QString subUri = firstText(r5.body, "Uri");
                            if (!subUri.isEmpty())
                                out.subUrl = withCredentials(subUri, req);
                        }
                        jobDone(idx, out, gen);   // без подпотока тоже успех
                    });
                });
            });
        });
    });
}
