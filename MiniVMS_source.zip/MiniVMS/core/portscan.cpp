#include "core/portscan.h"

#include <QHostAddress>
#include <QTcpSocket>
#include <QTimer>

#include <memory>

PortScanner::PortScanner(QObject *parent) : QObject(parent) {}

void PortScanner::start(quint32 firstIp, quint32 lastIp, quint16 port, int concurrency, int timeoutMs)
{
    stop();
    ++m_gen;
    m_next = firstIp;
    m_last = lastIp;
    m_port = port;
    m_conc = qMax(1, concurrency);
    m_timeout = timeoutMs;
    m_total = int(m_last - m_next + 1);
    m_done = 0;
    m_active = 0;
    m_running = true;
    pump();
}

void PortScanner::stop()
{
    m_running = false;
    ++m_gen;
}

void PortScanner::pump()
{
    while (m_running && m_active < m_conc && m_next <= m_last) {
        const QString ip = QHostAddress(quint32(m_next++)).toString();
        const int gen = m_gen;
        ++m_active;

        auto *sock = new QTcpSocket(this);
        auto *timer = new QTimer(sock);      // удалится вместе с сокетом
        timer->setSingleShot(true);
        auto done = std::make_shared<bool>(false);

        auto finish = [this, sock, gen, ip, done](bool open) {
            if (*done)
                return;
            *done = true;
            sock->abort();
            sock->deleteLater();
            if (gen != m_gen)
                return;
            --m_active;
            ++m_done;
            if (open)
                emit found(ip);
            emit progress(m_done, m_total);
            pump();
        };

        connect(sock, &QTcpSocket::connected, this, [finish] { finish(true); });
        connect(sock, &QAbstractSocket::errorOccurred, this,
                [finish](QAbstractSocket::SocketError) { finish(false); });
        connect(timer, &QTimer::timeout, this, [finish] { finish(false); });

        timer->start(m_timeout);
        sock->connectToHost(ip, m_port);
    }

    if (m_running && m_next > m_last && m_active == 0) {
        m_running = false;
        emit finished();
    }
}
