#pragma once

#include <QString>
#include <QUrl>

// Камеры iCSee построены на чипах Xiongmai (XM, они же XMeye/Sofia).
// RTSP-адрес у них особый: логин и пароль передаются прямо в пути.
//   stream = 0 — основной поток, stream = 1 — дополнительный (меньше разрешение)
//   channel — номер канала (у камеры обычно 1, у регистраторов 1..N)
inline QString icseeRtspUrl(const QString &host, quint16 port, const QString &user,
                            const QString &pass, int channel, int stream)
{
    return QStringLiteral("rtsp://%1:%2/user=%3&password=%4&channel=%5&stream=%6.sdp?real_stream")
        .arg(host)
        .arg(port)
        .arg(QString::fromUtf8(QUrl::toPercentEncoding(user)),
             QString::fromUtf8(QUrl::toPercentEncoding(pass)))
        .arg(channel)
        .arg(stream);
}
