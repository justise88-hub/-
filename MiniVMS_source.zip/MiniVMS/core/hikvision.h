#pragma once

#include <QList>
#include <QObject>
#include <QSet>
#include <QString>
#include <QUrl>

class QNetworkAccessManager;
class QTimer;
class QUdpSocket;

// Hikvision и её бренд HiWatch используют одни и те же протоколы:
//   RTSP:  rtsp://логин:пароль@IP:554/Streaming/Channels/<канал*100 + поток>
//          поток 1 — основной, 2 — дополнительный (канал 1: 101 и 102, канал 2: 201 и 202, ...)
//   ISAPI: http://IP/ISAPI/System/deviceInfo и /ISAPI/Streaming/channels (HTTP Digest)
inline QString hikRtspUrl(const QString &host, quint16 port, const QString &user, const QString &pass,
                          int channel, int stream)
{
    QUrl u;
    u.setScheme(QStringLiteral("rtsp"));
    u.setHost(host);
    u.setPort(port);
    u.setUserName(user);
    u.setPassword(pass);
    u.setPath(QStringLiteral("/Streaming/Channels/%1").arg(channel * 100 + stream));
    return u.toString(QUrl::FullyEncoded);
}

struct HikChannel {
    int number = 1;
    QString name;
};

struct HikDevice {
    QString address;
    quint16 httpPort = 80;
    QString model;
    QString name;
    QString serial;
    QString type;           // IPCamera, NVR, DVR ...
    bool activated = true;
    QList<HikChannel> channels;

    bool isRecorder() const
    {
        return type.contains(QLatin1String("NVR"), Qt::CaseInsensitive)
               || type.contains(QLatin1String("DVR"), Qt::CaseInsensitive);
    }
};

struct HikRequest {
    QString address;
    quint16 httpPort = 80;
    QString user;
    QString password;
    int fallbackChannels = 0;   // сколько каналов у регистратора, если список получить не удалось
};

struct HikResult {
    bool ok = false;
    QString error;
    HikDevice device;
};

// Поиск устройств по протоколу SADP (multicast 239.255.255.250:37020) — как в программе SADP Tool.
// Работает в своей подсети. Ответ зависит от прошивки, поэтому для других подсетей
// используйте сканирование диапазона IP.
class HikDiscovery : public QObject {
    Q_OBJECT
public:
    explicit HikDiscovery(QObject *parent = nullptr);
    void start(int timeoutMs = 4000);
    void stop();

signals:
    void deviceFound(const HikDevice &dev);
    void finished();

private:
    void sendProbes();
    void onReadyRead();

    QUdpSocket *m_socket = nullptr;
    QTimer *m_timer = nullptr;
    QSet<QString> m_seen;
    bool m_running = false;
};

// Пакетный опрос по ISAPI: тип устройства, модель и список каналов (камера = 1 канал,
// регистратор = все его каналы). Одновременно опрашивается не более `concurrency` устройств.
class HikResolver : public QObject {
    Q_OBJECT
public:
    explicit HikResolver(QObject *parent = nullptr);
    void start(const QList<HikRequest> &requests, int concurrency = 8);
    void cancel();

signals:
    void resolved(int index, const HikResult &result);
    void progress(int done, int total);
    void finished();

private:
    void pump();
    void runJob(int idx);
    void jobDone(int idx, const HikResult &r, int gen);

    QNetworkAccessManager *m_nam = nullptr;
    QList<HikRequest> m_requests;
    int m_next = 0;
    int m_done = 0;
    int m_active = 0;
    int m_conc = 8;
    int m_gen = 0;
    bool m_running = false;
};
