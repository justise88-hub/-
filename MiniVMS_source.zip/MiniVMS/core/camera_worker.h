#pragma once

#include <QString>
#include <QThread>
#include <atomic>

class RecordingIndex;

struct CameraConfig {
    QString id;                 // уникальный id камеры: попадает в пути файлов и в БД
    QString name;               // отображаемое имя
    QString url;                // rtsp://login:password@host:554/...
    QString storageRoot;        // корневая папка архива
    QString dbPath;             // путь к SQLite-файлу с индексом
    int segmentSeconds = 300;   // длительность одного сегмента
    int ioTimeoutMs = 10000;    // таймаут открытия и чтения потока
};

// Один поток на камеру: читает пакеты через libavformat и пишет их БЕЗ перекодирования
// в mkv-сегменты фиксированной длительности. Сегмент всегда начинается с ключевого кадра.
// Метаданные сегментов попадают в SQLite (RecordingIndex).
// При обрыве потока переподключается с нарастающей паузой (1 с ... 30 с).
class CameraWorker : public QThread {
    Q_OBJECT
public:
    enum class State { Stopped, Connecting, Recording, Reconnecting };
    Q_ENUM(State)

    explicit CameraWorker(CameraConfig cfg, QObject *parent = nullptr);
    ~CameraWorker() override;

    const CameraConfig &config() const { return m_cfg; }

    void startRecording();   // вместо start(): сбрасывает флаг остановки
    void stop();             // не блокирует; после него вызвать wait()

signals:
    void stateChanged(const QString &cameraId, CameraWorker::State state);
    void segmentStarted(const QString &cameraId, const QString &path, qint64 startMs);
    void segmentFinished(const QString &cameraId, const QString &path,
                         qint64 startMs, qint64 endMs, qint64 sizeBytes);
    void errorOccurred(const QString &cameraId, const QString &message);

protected:
    void run() override;

private:
    void recordSession(RecordingIndex &index, bool &gotData);
    QString segmentPath(qint64 startMs) const;
    void armDeadline(int ms);
    void sleepInterruptible(int ms);
    static int interruptCallback(void *opaque);

    CameraConfig m_cfg;
    std::atomic<bool> m_stop{false};
    std::atomic<qint64> m_deadlineMs{0};
};
