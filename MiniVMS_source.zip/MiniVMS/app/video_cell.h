#pragma once

#include <QFrame>
#include <QString>
#include <QUrl>

class QLabel;
class QMediaPlayer;
class QStackedLayout;
class QTimer;
class QToolButton;
class QVideoWidget;

// Одна ячейка мозаики: заголовок с названием камеры, видео и крестик закрытия.
// Принимает камеру перетаскиванием из списка. Сама переподключается при обрыве.
class VideoCell : public QFrame {
    Q_OBJECT
public:
    explicit VideoCell(QWidget *parent = nullptr);

    bool isEmpty() const { return m_cameraId.isEmpty(); }
    QString cameraId() const { return m_cameraId; }
    QUrl url() const { return m_url; }

    void play(const QString &cameraId, const QString &title, const QUrl &url);
    void setTitle(const QString &title);
    void clear();
    void setSelected(bool on);

signals:
    void clicked(VideoCell *cell);
    void doubleClicked(VideoCell *cell);
    void cameraDropped(VideoCell *cell, const QString &cameraId);

protected:
    bool eventFilter(QObject *obj, QEvent *e) override;
    void mousePressEvent(QMouseEvent *e) override;
    void mouseDoubleClickEvent(QMouseEvent *e) override;
    void dragEnterEvent(QDragEnterEvent *e) override;
    void dropEvent(QDropEvent *e) override;

private:
    void restart();

    QString m_cameraId;
    QUrl m_url;
    QLabel *m_title = nullptr;
    QLabel *m_placeholder = nullptr;
    QToolButton *m_close = nullptr;
    QStackedLayout *m_stack = nullptr;
    QVideoWidget *m_video = nullptr;
    QMediaPlayer *m_player = nullptr;
    QTimer *m_retry = nullptr;
};
