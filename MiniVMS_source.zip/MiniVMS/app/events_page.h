#pragma once

#include <QWidget>

class QTableWidget;

// Журнал событий: потеря связи, ошибки записи, смена состояния камер.
// Позже сюда же попадут события детектора движения.
class EventsPage : public QWidget {
    Q_OBJECT
public:
    explicit EventsPage(QWidget *parent = nullptr);

    void addEvent(const QString &camera, const QString &text);

private:
    QTableWidget *m_table = nullptr;
};
