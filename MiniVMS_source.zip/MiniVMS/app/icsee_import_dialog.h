#pragma once

#include <QDialog>
#include <QSet>
#include <QStringList>

#include "app/camera_manager.h"
#include "core/portscan.h"

class QLabel;
class QLineEdit;
class QProgressBar;
class QPushButton;
class QSpinBox;
class QTableWidget;

// Добавление камер iCSee (Xiongmai): сканируем диапазон IP на открытый RTSP-порт,
// отмечаем найденные и добавляем. RTSP-адреса строятся по шаблону iCSee:
// основной поток (stream=0) для записи и подпоток (stream=1) для мозаики.
// Для одной камеры укажите одинаковые адреса «от» и «до».
class IcseeImportDialog : public QDialog {
    Q_OBJECT
public:
    explicit IcseeImportDialog(CameraManager *mgr, QWidget *parent = nullptr);

private slots:
    void startScan();
    void addHost(const QString &ip);
    void addSelected();
    void setAllChecked(bool on);

private:
    CameraManager *m_mgr;
    PortScanner *m_scanner = nullptr;

    QLineEdit *m_from = nullptr;
    QLineEdit *m_to = nullptr;
    QSpinBox *m_port = nullptr;
    QLineEdit *m_user = nullptr;
    QLineEdit *m_pass = nullptr;
    QLineEdit *m_group = nullptr;
    QTableWidget *m_table = nullptr;
    QProgressBar *m_progress = nullptr;
    QLabel *m_status = nullptr;
    QPushButton *m_btnScan = nullptr;
    QPushButton *m_btnAdd = nullptr;

    QStringList m_hosts;          // строка таблицы i == m_hosts[i]
    QSet<QString> m_existing;     // уже добавленные камеры (по IP)
};
