#include "app/hikvision_import_dialog.h"

#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QHostAddress>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QSpinBox>
#include <QTableWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

enum Column { ColCheck, ColAddress, ColModel, ColState, ColCount };
constexpr int kMaxRange = 2048;

bool parseIpv4(const QString &s, quint32 *out)
{
    QHostAddress a;
    if (!a.setAddress(s.trimmed()) || a.protocol() != QAbstractSocket::IPv4Protocol)
        return false;
    *out = a.toIPv4Address();
    return true;
}

} // namespace

HikvisionImportDialog::HikvisionImportDialog(CameraManager *mgr, QWidget *parent)
    : QDialog(parent), m_mgr(mgr)
{
    setWindowTitle(QStringLiteral("Добавить Hikvision / HiWatch"));
    resize(980, 660);

    for (const CameraEntry &e : m_mgr->cameras())
        m_existing.insert(QUrl(e.url).host());

    m_discovery = new HikDiscovery(this);
    m_scanner = new PortScanner(this);
    m_resolver = new HikResolver(this);

    // ---- поиск ----
    auto *findBox = new QGroupBox(QStringLiteral("1. Поиск устройств"), this);
    auto *findLay = new QHBoxLayout(findBox);
    m_btnDiscover = new QPushButton(QStringLiteral("Найти в сети (SADP)"), findBox);
    m_from = new QLineEdit(findBox);
    m_from->setPlaceholderText(QStringLiteral("192.168.1.1"));
    m_to = new QLineEdit(findBox);
    m_to->setPlaceholderText(QStringLiteral("192.168.1.254"));
    m_httpPort = new QSpinBox(findBox);
    m_httpPort->setRange(1, 65535);
    m_httpPort->setValue(80);
    m_btnScan = new QPushButton(QStringLiteral("Сканировать диапазон"), findBox);
    findLay->addWidget(m_btnDiscover);
    findLay->addSpacing(16);
    findLay->addWidget(new QLabel(QStringLiteral("Диапазон IP:"), findBox));
    findLay->addWidget(m_from);
    findLay->addWidget(new QLabel(QStringLiteral("—"), findBox));
    findLay->addWidget(m_to);
    findLay->addWidget(new QLabel(QStringLiteral("HTTP-порт"), findBox));
    findLay->addWidget(m_httpPort);
    findLay->addWidget(m_btnScan);

    // ---- доступ ----
    auto *authBox = new QGroupBox(QStringLiteral("2. Доступ"), this);
    auto *authLay = new QHBoxLayout(authBox);
    m_user = new QLineEdit(QStringLiteral("admin"), authBox);
    m_pass = new QLineEdit(authBox);
    m_pass->setEchoMode(QLineEdit::Password);
    m_group = new QLineEdit(authBox);
    m_group->setPlaceholderText(QStringLiteral("для регистратора — по умолчанию его имя"));
    m_rtspPort = new QSpinBox(authBox);
    m_rtspPort->setRange(1, 65535);
    m_rtspPort->setValue(554);
    m_fallback = new QSpinBox(authBox);
    m_fallback->setRange(0, 128);
    m_fallback->setSpecialValueText(QStringLiteral("авто"));
    m_fallback->setToolTip(QStringLiteral("Число каналов регистратора, если автоопределение не сработало"));
    authLay->addWidget(new QLabel(QStringLiteral("Логин:"), authBox));
    authLay->addWidget(m_user);
    authLay->addWidget(new QLabel(QStringLiteral("Пароль:"), authBox));
    authLay->addWidget(m_pass);
    authLay->addWidget(new QLabel(QStringLiteral("Группа:"), authBox));
    authLay->addWidget(m_group, 1);
    authLay->addWidget(new QLabel(QStringLiteral("RTSP-порт"), authBox));
    authLay->addWidget(m_rtspPort);
    authLay->addWidget(new QLabel(QStringLiteral("Каналов в регистраторе:"), authBox));
    authLay->addWidget(m_fallback);

    // ---- таблица ----
    m_table = new QTableWidget(0, ColCount, this);
    m_table->setHorizontalHeaderLabels({QString(), QStringLiteral("Адрес"),
                                        QStringLiteral("Модель / тип"), QStringLiteral("Состояние")});
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionMode(QAbstractItemView::NoSelection);
    m_table->verticalHeader()->setVisible(false);
    m_table->setColumnWidth(ColCheck, 34);
    m_table->setColumnWidth(ColAddress, 150);
    m_table->setColumnWidth(ColModel, 340);
    m_table->horizontalHeader()->setSectionResizeMode(ColState, QHeaderView::Stretch);

    auto *selAll = new QPushButton(QStringLiteral("Выбрать все"), this);
    auto *selNone = new QPushButton(QStringLiteral("Снять выбор"), this);
    auto *selRow = new QHBoxLayout;
    selRow->addWidget(new QLabel(QStringLiteral("3. Найденные устройства"), this));
    selRow->addStretch(1);
    selRow->addWidget(selAll);
    selRow->addWidget(selNone);

    // ---- низ ----
    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1);
    m_progress->setValue(0);
    m_status = new QLabel(QStringLiteral("Найдите устройства, введите логин и пароль и нажмите «Добавить выбранные»."), this);
    m_btnImport = new QPushButton(QStringLiteral("Добавить выбранные"), this);
    auto *close = new QPushButton(QStringLiteral("Закрыть"), this);

    auto *bottom = new QHBoxLayout;
    bottom->addWidget(m_progress, 1);
    bottom->addWidget(m_btnImport);
    bottom->addWidget(close);

    auto *root = new QVBoxLayout(this);
    root->addWidget(findBox);
    root->addWidget(authBox);
    root->addLayout(selRow);
    root->addWidget(m_table, 1);
    root->addWidget(m_status);
    root->addLayout(bottom);

    // ---- сигналы ----
    connect(m_btnDiscover, &QPushButton::clicked, this, &HikvisionImportDialog::startDiscovery);
    connect(m_btnScan, &QPushButton::clicked, this, &HikvisionImportDialog::startScan);
    connect(m_btnImport, &QPushButton::clicked, this, &HikvisionImportDialog::importSelected);
    connect(selAll, &QPushButton::clicked, this, [this] { setAllChecked(true); });
    connect(selNone, &QPushButton::clicked, this, [this] { setAllChecked(false); });
    connect(close, &QPushButton::clicked, this, &QDialog::accept);

    connect(m_discovery, &HikDiscovery::deviceFound, this, [this](const HikDevice &d) {
        addCandidate(d.address, d.httpPort, d.model);
    });
    connect(m_discovery, &HikDiscovery::finished, this, [this] {
        m_progress->setRange(0, 1);
        m_progress->setValue(1);
        m_status->setText(QStringLiteral("Поиск завершён. Найдено устройств: %1. Если список пуст, используйте сканирование диапазона.")
                              .arg(m_candidates.size()));
        setBusy(false);
    });

    connect(m_scanner, &PortScanner::found, this, [this](const QString &ip) {
        addCandidate(ip, quint16(m_httpPort->value()), QString());
    });
    connect(m_scanner, &PortScanner::progress, this, [this](int done, int total) {
        m_progress->setRange(0, total);
        m_progress->setValue(done);
        m_status->setText(QStringLiteral("Проверено %1 из %2, найдено: %3").arg(done).arg(total).arg(m_candidates.size()));
    });
    connect(m_scanner, &PortScanner::finished, this, [this] {
        m_status->setText(QStringLiteral("Сканирование завершено. Найдено адресов: %1").arg(m_candidates.size()));
        setBusy(false);
    });

    connect(m_resolver, &HikResolver::progress, this, [this](int done, int total) {
        m_progress->setRange(0, total);
        m_progress->setValue(done);
        m_status->setText(QStringLiteral("Опрос устройств: %1 из %2").arg(done).arg(total));
    });
    connect(m_resolver, &HikResolver::resolved, this, [this](int i, const HikResult &r) {
        const int row = m_importRows.at(i);
        if (!r.ok) {
            ++m_failed;
            m_table->item(row, ColState)->setText(r.error);
            return;
        }
        const HikDevice &d = r.device;
        const bool rec = d.isRecorder();
        const QString base = !d.name.isEmpty() ? d.name : (!d.model.isEmpty() ? d.model : d.address);

        QString group = m_group->text().trimmed();
        if (group.isEmpty() && rec)
            group = QStringLiteral("%1 (%2)").arg(base, d.address);

        for (const HikChannel &c : d.channels) {
            const QString chName = c.name.isEmpty() ? QStringLiteral("Канал %1").arg(c.number) : c.name;
            CameraEntry e;
            e.name = rec ? QStringLiteral("%1 — %2").arg(d.address, chName)
                         : (base == d.address ? d.address : QStringLiteral("%1 (%2)").arg(base, d.address));
            e.group = group;
            e.url = hikRtspUrl(d.address, m_curRtsp, m_curUser, m_curPass, c.number, 1);      // основной
            e.liveUrl = hikRtspUrl(d.address, m_curRtsp, m_curUser, m_curPass, c.number, 2);  // подпоток
            e.record = true;
            m_pending.append(e);
        }
        m_pendingRows.append(row);
        ++m_devicesOk;

        const QString kind = rec ? QStringLiteral("регистратор") : QStringLiteral("камера");
        m_table->item(row, ColModel)->setText(
            QStringLiteral("%1 — %2, каналов: %3").arg(d.model.isEmpty() ? base : d.model, kind).arg(d.channels.size()));
        m_table->item(row, ColState)->setText(QStringLiteral("Готово к добавлению"));
    });
    connect(m_resolver, &HikResolver::finished, this, [this] {
        if (!m_pending.isEmpty())
            m_mgr->addMany(m_pending);
        for (int row : std::as_const(m_pendingRows)) {
            m_table->item(row, ColState)->setText(QStringLiteral("Добавлено"));
            m_table->item(row, ColCheck)->setCheckState(Qt::Unchecked);
            m_table->item(row, ColCheck)->setFlags(Qt::NoItemFlags);
            m_existing.insert(m_candidates.at(row).address);
        }
        m_status->setText(QStringLiteral("Добавлено каналов: %1 (устройств: %2), с ошибкой: %3%4")
                              .arg(m_pending.size()).arg(m_devicesOk).arg(m_failed)
                              .arg(m_failed ? QStringLiteral(" — исправьте логин/пароль и повторите") : QString()));
        m_pending.clear();
        m_pendingRows.clear();
        setBusy(false);
    });
}

void HikvisionImportDialog::addCandidate(const QString &ip, quint16 httpPort, const QString &model)
{
    for (const Candidate &c : std::as_const(m_candidates))
        if (c.address == ip)
            return;

    const int row = m_table->rowCount();
    m_table->insertRow(row);
    Candidate c;
    c.address = ip;
    c.httpPort = httpPort ? httpPort : 80;
    m_candidates.append(c);

    const bool exists = m_existing.contains(ip);
    auto *chk = new QTableWidgetItem;
    chk->setFlags(exists ? Qt::NoItemFlags : (Qt::ItemIsUserCheckable | Qt::ItemIsEnabled));
    chk->setCheckState(exists ? Qt::Unchecked : Qt::Checked);
    m_table->setItem(row, ColCheck, chk);
    m_table->setItem(row, ColAddress, new QTableWidgetItem(ip));
    m_table->setItem(row, ColModel, new QTableWidgetItem(model));
    m_table->setItem(row, ColState,
                     new QTableWidgetItem(exists ? QStringLiteral("Уже добавлено") : QStringLiteral("Найдено")));
}

void HikvisionImportDialog::setAllChecked(bool on)
{
    for (int row = 0; row < m_table->rowCount(); ++row) {
        QTableWidgetItem *it = m_table->item(row, ColCheck);
        if (it->flags() & Qt::ItemIsUserCheckable)
            it->setCheckState(on ? Qt::Checked : Qt::Unchecked);
    }
}

void HikvisionImportDialog::setBusy(bool busy)
{
    m_btnDiscover->setEnabled(!busy);
    m_btnScan->setEnabled(!busy);
    m_btnImport->setEnabled(!busy);
}

void HikvisionImportDialog::startDiscovery()
{
    setBusy(true);
    m_progress->setRange(0, 0);
    m_status->setText(QStringLiteral("Поиск устройств в сети…"));
    m_discovery->start(4000);
}

void HikvisionImportDialog::startScan()
{
    quint32 a = 0, b = 0;
    if (!parseIpv4(m_from->text(), &a) || !parseIpv4(m_to->text(), &b) || b < a) {
        QMessageBox::warning(this, windowTitle(), QStringLiteral("Укажите корректный диапазон IPv4-адресов."));
        return;
    }
    if (quint64(b) - a + 1 > kMaxRange) {
        QMessageBox::warning(this, windowTitle(),
            QStringLiteral("Слишком большой диапазон: максимум %1 адресов за раз.").arg(kMaxRange));
        return;
    }
    setBusy(true);
    m_progress->setRange(0, int(b - a + 1));
    m_progress->setValue(0);
    m_scanner->start(a, b, quint16(m_httpPort->value()), 64, 800);
}

void HikvisionImportDialog::importSelected()
{
    if (m_user->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, windowTitle(), QStringLiteral("Укажите логин."));
        return;
    }
    m_curUser = m_user->text().trimmed();
    m_curPass = m_pass->text();
    m_curRtsp = quint16(m_rtspPort->value());

    m_importRows.clear();
    m_pending.clear();
    m_pendingRows.clear();
    m_failed = 0;
    m_devicesOk = 0;

    QList<HikRequest> requests;
    for (int row = 0; row < m_table->rowCount(); ++row) {
        const QTableWidgetItem *chk = m_table->item(row, ColCheck);
        if (!(chk->flags() & Qt::ItemIsUserCheckable) || chk->checkState() != Qt::Checked)
            continue;
        HikRequest r;
        r.address = m_candidates.at(row).address;
        r.httpPort = m_candidates.at(row).httpPort;
        r.user = m_curUser;
        r.password = m_curPass;
        r.fallbackChannels = m_fallback->value();
        requests.append(r);
        m_importRows.append(row);
        m_table->item(row, ColState)->setText(QStringLiteral("Запрос…"));
    }
    if (requests.isEmpty()) {
        QMessageBox::information(this, windowTitle(), QStringLiteral("Отметьте устройства для добавления."));
        return;
    }

    setBusy(true);
    m_progress->setRange(0, int(requests.size()));
    m_progress->setValue(0);
    m_resolver->start(requests, 8);
}
