#include "app/playback_page.h"
#include "app/camera_manager.h"

#include <QAudioOutput>
#include <QCalendarWidget>
#include <QComboBox>
#include <QDateTime>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QLabel>
#include <QListWidget>
#include <QMediaPlayer>
#include <QPushButton>
#include <QSlider>
#include <QUrl>
#include <QVBoxLayout>
#include <QVideoWidget>

namespace {

QString formatMs(qint64 ms)
{
    const qint64 s = ms / 1000;
    return QStringLiteral("%1:%2").arg(s / 60, 2, 10, QLatin1Char('0')).arg(s % 60, 2, 10, QLatin1Char('0'));
}

} // namespace

PlaybackPage::PlaybackPage(CameraManager *mgr, QWidget *parent) : QWidget(parent), m_mgr(mgr)
{
    m_index.open(mgr->dbPath());

    // ---- левая колонка: камера, календарь, сегменты ----
    m_camera = new QComboBox(this);
    m_calendar = new QCalendarWidget(this);
    m_calendar->setGridVisible(true);
    m_calendar->setMaximumDate(QDate::currentDate());
    m_list = new QListWidget(this);
    auto *refresh = new QPushButton(QStringLiteral("Обновить"), this);

    auto *left = new QVBoxLayout;
    left->addWidget(m_camera);
    left->addWidget(m_calendar);
    left->addWidget(new QLabel(QStringLiteral("Записи за день (двойной щелчок — воспроизвести):"), this));
    left->addWidget(m_list, 1);
    left->addWidget(refresh);

    auto *leftBox = new QWidget(this);
    leftBox->setLayout(left);
    leftBox->setFixedWidth(340);

    // ---- правая часть: видео и управление ----
    m_video = new QVideoWidget(this);
    m_video->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    m_player = new QMediaPlayer(this);
    m_audio = new QAudioOutput(this);
    m_player->setAudioOutput(m_audio);
    m_player->setVideoOutput(m_video);

    m_playBtn = new QPushButton(QStringLiteral("▶"), this);
    m_playBtn->setFixedWidth(48);
    m_slider = new QSlider(Qt::Horizontal, this);
    m_time = new QLabel(QStringLiteral("00:00 / 00:00"), this);

    auto *controls = new QHBoxLayout;
    controls->addWidget(m_playBtn);
    controls->addWidget(m_slider, 1);
    controls->addWidget(m_time);

    auto *right = new QVBoxLayout;
    right->addWidget(m_video, 1);
    right->addLayout(controls);

    auto *root = new QHBoxLayout(this);
    root->setContentsMargins(12, 12, 12, 12);
    root->addWidget(leftBox);
    root->addLayout(right, 1);

    // ---- сигналы ----
    connect(m_mgr, &CameraManager::camerasChanged, this, &PlaybackPage::reloadCameras);
    connect(m_camera, &QComboBox::currentIndexChanged, this, &PlaybackPage::reloadSegments);
    connect(m_calendar, &QCalendarWidget::selectionChanged, this, &PlaybackPage::reloadSegments);
    connect(refresh, &QPushButton::clicked, this, &PlaybackPage::reloadSegments);
    connect(m_list, &QListWidget::itemDoubleClicked, this, &PlaybackPage::playCurrent);
    connect(m_playBtn, &QPushButton::clicked, this, &PlaybackPage::togglePlay);

    connect(m_player, &QMediaPlayer::durationChanged, this, [this](qint64 d) {
        m_slider->setRange(0, int(d));
    });
    connect(m_player, &QMediaPlayer::positionChanged, this, [this](qint64 p) {
        if (!m_slider->isSliderDown())
            m_slider->setValue(int(p));
        m_time->setText(formatMs(p) + QStringLiteral(" / ") + formatMs(m_player->duration()));
    });
    connect(m_slider, &QSlider::sliderMoved, m_player, &QMediaPlayer::setPosition);
    connect(m_player, &QMediaPlayer::playbackStateChanged, this, [this](QMediaPlayer::PlaybackState s) {
        m_playBtn->setText(s == QMediaPlayer::PlayingState ? QStringLiteral("⏸") : QStringLiteral("▶"));
    });

    reloadCameras();
}

void PlaybackPage::showEvent(QShowEvent *e)
{
    QWidget::showEvent(e);
    m_calendar->setMaximumDate(QDate::currentDate());
    reloadSegments();   // подхватить сегменты, записанные пока страница была скрыта
}

void PlaybackPage::reloadCameras()
{
    const QString keep = m_camera->currentData().toString();

    m_camera->blockSignals(true);
    m_camera->clear();
    for (const CameraEntry &e : m_mgr->cameras())
        m_camera->addItem(e.name, e.id);
    const int idx = m_camera->findData(keep);
    if (idx >= 0)
        m_camera->setCurrentIndex(idx);
    m_camera->blockSignals(false);

    reloadSegments();
}

void PlaybackPage::reloadSegments()
{
    m_list->clear();
    const QString camId = m_camera->currentData().toString();
    if (camId.isEmpty())
        return;

    const QDate day = m_calendar->selectedDate();
    const qint64 from = day.startOfDay().toMSecsSinceEpoch();
    const qint64 to = day.addDays(1).startOfDay().toMSecsSinceEpoch();

    for (const SegmentInfo &s : m_index.segmentsInRange(camId, from, to)) {
        QString text = QDateTime::fromMSecsSinceEpoch(s.startMs).toString(QStringLiteral("HH:mm:ss"))
                       + QStringLiteral(" — ");
        text += s.endMs ? QDateTime::fromMSecsSinceEpoch(s.endMs).toString(QStringLiteral("HH:mm:ss"))
                        : QStringLiteral("идёт запись");
        if (s.sizeBytes > 0)
            text += QStringLiteral("    %1 МБ").arg(s.sizeBytes / 1048576.0, 0, 'f', 1);

        auto *it = new QListWidgetItem(text, m_list);
        it->setData(Qt::UserRole, s.path);
    }
}

void PlaybackPage::playCurrent()
{
    const QListWidgetItem *it = m_list->currentItem();
    if (!it)
        return;
    const QString path = it->data(Qt::UserRole).toString();
    if (!QFileInfo::exists(path))
        return;
    m_player->setSource(QUrl::fromLocalFile(path));
    m_player->play();
}

void PlaybackPage::togglePlay()
{
    if (m_player->playbackState() == QMediaPlayer::PlayingState)
        m_player->pause();
    else
        m_player->play();
}
