#pragma once

#include <QDialog>
#include <QList>
#include <QSet>

#include "app/camera_manager.h"
#include "core/onvif.h"

class QLabel;
class QLineEdit;
class QProgressBar;
class QPushButton;
class QSpinBox;
class QTableWidget;

// Массовое добавление камер по ONVIF:
//   1. найти устройства (multicast в своей подсети или сканирование диапазона IP),
//   2. указать общий логин и пароль,
//   3. отметить нужные и нажать «Добавить»: программа сама получит RTSP-адреса
//      основного потока (для записи) и подпотока (для мозаики).
class OnvifImportDialog : public QDialog {
    Q_OBJECT
public:
    explicit OnvifImportDialog(CameraManager *mgr, QWidget *parent = nullptr);

private slots:
    void startDiscovery();
    void startScan();
    void addDevice(const OnvifDevice &dev);
    void importSelected();
    void setAllChecked(bool on);

private:
    QString displayName(int row) const;
    void setBusy(bool busy);

    CameraManager *m_mgr;
    OnvifDiscovery *m_discovery = nullptr;
    OnvifScanner *m_scanner = nullptr;
    OnvifResolver *m_resolver = nullptr;

    QLineEdit *m_from = nullptr;
    QLineEdit *m_to = nullptr;
    QSpinBox *m_port = nullptr;
    QLineEdit *m_user = nullptr;
    QLineEdit *m_pass = nullptr;
    QLineEdit *m_group = nullptr;
    QTableWidget *m_table = nullptr;
    QProgressBar *m_progress = nullptr;
    QLabel *m_status = nullptr;
    QPushButton *m_btnDiscover = nullptr;
    QPushButton *m_btnScan = nullptr;
    QPushButton *m_btnImport = nullptr;

    QList<OnvifDevice> m_devices;        // строка таблицы i == m_devices[i]
    QSet<QString> m_existingHosts;       // уже добавленные камеры (по IP)
    QList<int> m_importRows;             // строки, ушедшие в опрос (по порядку запросов)
    QList<CameraEntry> m_pending;        // успешно опрошенные камеры
    QList<int> m_pendingRows;
    int m_failed = 0;
};
