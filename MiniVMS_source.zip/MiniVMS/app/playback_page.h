#pragma once

#include <QWidget>

#include "core/recording_index.h"

class CameraManager;
class QAudioOutput;
class QCalendarWidget;
class QComboBox;
class QLabel;
class QListWidget;
class QMediaPlayer;
class QPushButton;
class QSlider;
class QVideoWidget;

// Архив: выбор камеры и даты, список сегментов из индекса SQLite, воспроизведение.
class PlaybackPage : public QWidget {
    Q_OBJECT
public:
    explicit PlaybackPage(CameraManager *mgr, QWidget *parent = nullptr);

protected:
    void showEvent(QShowEvent *e) override;

private slots:
    void reloadCameras();
    void reloadSegments();
    void playCurrent();
    void togglePlay();

private:
    CameraManager *m_mgr;
    RecordingIndex m_index;   // соединение с БД живёт в GUI-потоке

    QComboBox *m_camera = nullptr;
    QCalendarWidget *m_calendar = nullptr;
    QListWidget *m_list = nullptr;
    QVideoWidget *m_video = nullptr;
    QMediaPlayer *m_player = nullptr;
    QAudioOutput *m_audio = nullptr;
    QPushButton *m_playBtn = nullptr;
    QSlider *m_slider = nullptr;
    QLabel *m_time = nullptr;
};
