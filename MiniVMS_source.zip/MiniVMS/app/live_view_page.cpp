#include "app/live_view_page.h"
#include "app/camera_manager.h"
#include "app/camera_tree.h"
#include "app/video_grid.h"

#include <QButtonGroup>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>
#include <QLineEdit>
#include <QMap>
#include <QPainter>
#include <QPixmap>
#include <QPushButton>
#include <QSlider>
#include <QSplitter>
#include <QToolButton>
#include <QTreeWidgetItem>
#include <QVBoxLayout>

namespace {

QIcon dotIcon(const QColor &c)
{
    QPixmap pm(12, 12);
    pm.fill(Qt::transparent);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing);
    p.setPen(Qt::NoPen);
    p.setBrush(c);
    p.drawEllipse(1, 1, 10, 10);
    return QIcon(pm);
}

QColor stateColor(CameraWorker::State s)
{
    switch (s) {
    case CameraWorker::State::Recording:    return QColor("#3fb950");   // зелёный
    case CameraWorker::State::Connecting:
    case CameraWorker::State::Reconnecting: return QColor("#e8833a");   // оранжевый
    case CameraWorker::State::Stopped:      break;
    }
    return QColor("#6b7480");                                           // серый
}

// Панель PTZ — пока только интерфейс; управление по ONVIF подключим позже.
QWidget *makePtzPanel(QWidget *parent)
{
    auto *box = new QGroupBox(QStringLiteral("PTZ-управление"), parent);
    auto *lay = new QGridLayout(box);

    const char *arrows[9] = {"↖", "↑", "↗", "←", "●", "→", "↙", "↓", "↘"};
    for (int i = 0; i < 9; ++i) {
        auto *b = new QToolButton(box);
        b->setText(QString::fromUtf8(arrows[i]));
        b->setFixedSize(40, 32);
        b->setEnabled(false);
        lay->addWidget(b, i / 3, i % 3, Qt::AlignCenter);
    }

    auto *zoomOut = new QToolButton(box);
    zoomOut->setText(QStringLiteral("−"));
    zoomOut->setEnabled(false);
    auto *zoomIn = new QToolButton(box);
    zoomIn->setText(QStringLiteral("+"));
    zoomIn->setEnabled(false);
    lay->addWidget(new QLabel(QStringLiteral("Зум"), box), 3, 0);
    lay->addWidget(zoomOut, 3, 1, Qt::AlignCenter);
    lay->addWidget(zoomIn, 3, 2, Qt::AlignCenter);

    auto *speed = new QSlider(Qt::Horizontal, box);
    speed->setRange(1, 8);
    speed->setValue(4);
    speed->setEnabled(false);
    lay->addWidget(new QLabel(QStringLiteral("Скорость"), box), 4, 0);
    lay->addWidget(speed, 4, 1, 1, 2);

    auto *note = new QLabel(QStringLiteral("Управление по ONVIF будет добавлено позже"), box);
    note->setWordWrap(true);
    note->setStyleSheet(QStringLiteral("color:#6b7480; font-size:11px;"));
    lay->addWidget(note, 5, 0, 1, 3);
    return box;
}

} // namespace

LiveViewPage::LiveViewPage(CameraManager *mgr, QWidget *parent) : QWidget(parent), m_mgr(mgr)
{
    auto *root = new QHBoxLayout(this);
    root->setContentsMargins(0, 0, 0, 0);
    auto *split = new QSplitter(Qt::Horizontal, this);
    root->addWidget(split);

    // ---- левая панель: поиск, дерево камер, PTZ ----
    auto *left = new QWidget;
    auto *lv = new QVBoxLayout(left);
    lv->setContentsMargins(8, 8, 4, 8);

    m_search = new QLineEdit(left);
    m_search->setPlaceholderText(QStringLiteral("Поиск камеры…"));
    m_search->setClearButtonEnabled(true);

    m_tree = new CameraTree(left);
    m_tree->setHeaderHidden(true);
    m_tree->setDragEnabled(true);
    m_tree->setDragDropMode(QAbstractItemView::DragOnly);
    m_tree->setIndentation(14);

    lv->addWidget(m_search);
    lv->addWidget(m_tree, 1);
    lv->addWidget(makePtzPanel(left));
    left->setMinimumWidth(230);
    left->setMaximumWidth(380);

    // ---- центр: панель инструментов и мозаика ----
    auto *center = new QWidget;
    auto *cv = new QVBoxLayout(center);
    cv->setContentsMargins(4, 8, 8, 8);

    auto *tools = new QHBoxLayout;
    auto *group = new QButtonGroup(this);
    group->setExclusive(true);
    const struct { const char *text; int n; } layouts[] = {{"1", 1}, {"2×2", 4}, {"3×3", 9}, {"4×4", 16}};
    for (const auto &l : layouts) {
        auto *b = new QToolButton(center);
        b->setText(QString::fromUtf8(l.text));
        b->setCheckable(true);
        b->setMinimumWidth(46);
        b->setToolTip(QStringLiteral("Раскладка экрана"));
        if (l.n == 4)
            b->setChecked(true);
        group->addButton(b, l.n);
        tools->addWidget(b);
    }
    tools->addStretch(1);
    auto *stopAll = new QPushButton(QStringLiteral("Закрыть все"), center);
    auto *full = new QPushButton(QStringLiteral("Во весь экран"), center);
    tools->addWidget(stopAll);
    tools->addWidget(full);

    m_grid = new VideoGrid(mgr, center);
    cv->addLayout(tools);
    cv->addWidget(m_grid, 1);

    split->addWidget(left);
    split->addWidget(center);
    split->setStretchFactor(0, 0);
    split->setStretchFactor(1, 1);
    split->setCollapsible(0, false);
    split->setCollapsible(1, false);

    // ---- сигналы ----
    connect(group, &QButtonGroup::idClicked, m_grid, &VideoGrid::setLayoutCount);
    connect(stopAll, &QPushButton::clicked, m_grid, &VideoGrid::clearAll);
    connect(full, &QPushButton::clicked, this, [this] {
        QWidget *w = window();
        w->isFullScreen() ? w->showNormal() : w->showFullScreen();
    });
    connect(m_search, &QLineEdit::textChanged, this, &LiveViewPage::applyFilter);
    connect(m_tree, &QTreeWidget::itemDoubleClicked, this, [this](QTreeWidgetItem *it) {
        const QString id = it->data(0, Qt::UserRole).toString();
        if (!id.isEmpty())
            m_grid->openCamera(id);
    });
    connect(m_mgr, &CameraManager::camerasChanged, this, &LiveViewPage::rebuildTree);
    connect(m_mgr, &CameraManager::cameraStateChanged, this, &LiveViewPage::updateState);

    rebuildTree();
}

void LiveViewPage::rebuildTree()
{
    m_tree->clear();
    m_items.clear();

    QMap<QString, QTreeWidgetItem *> groups;
    for (const CameraEntry &e : m_mgr->cameras()) {
        const QString g = e.group.isEmpty() ? tr("Без группы") : e.group;
        QTreeWidgetItem *parent = groups.value(g, nullptr);
        if (!parent) {
            parent = new QTreeWidgetItem(m_tree, QStringList(g));
            parent->setFlags(Qt::ItemIsEnabled);
            groups.insert(g, parent);
        }
        auto *it = new QTreeWidgetItem(parent, QStringList(e.name));
        it->setData(0, Qt::UserRole, e.id);
        it->setIcon(0, dotIcon(stateColor(m_mgr->stateOf(e.id))));
        it->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsDragEnabled);
        m_items.insert(e.id, it);
    }
    m_tree->expandAll();
    applyFilter(m_search->text());
}

void LiveViewPage::updateState(const QString &id, CameraWorker::State state)
{
    if (QTreeWidgetItem *it = m_items.value(id, nullptr))
        it->setIcon(0, dotIcon(stateColor(state)));
}

void LiveViewPage::applyFilter(const QString &text)
{
    const QString t = text.trimmed();
    for (int g = 0; g < m_tree->topLevelItemCount(); ++g) {
        QTreeWidgetItem *grp = m_tree->topLevelItem(g);
        int visible = 0;
        for (int i = 0; i < grp->childCount(); ++i) {
            QTreeWidgetItem *c = grp->child(i);
            const bool show = t.isEmpty() || c->text(0).contains(t, Qt::CaseInsensitive);
            c->setHidden(!show);
            if (show)
                ++visible;
        }
        grp->setHidden(visible == 0);
    }
}
