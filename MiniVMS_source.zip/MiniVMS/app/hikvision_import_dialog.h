#pragma once

#include <QDialog>
#include <QList>
#include <QSet>

#include "app/camera_manager.h"
#include "core/hikvision.h"
#include "core/portscan.h"

class QLabel;
class QLineEdit;
class QProgressBar;
class QPushButton;
class QSpinBox;
class QTableWidget;

// Добавление камер и регистраторов Hikvision / HiWatch.
// Камера даёт один канал, регистратор — все свои каналы (основной поток для записи,
// дополнительный для мозаики). Для одной камеры или регистратора укажите одинаковые IP «от» и «до».
class HikvisionImportDialog : public QDialog {
    Q_OBJECT
public:
    explicit HikvisionImportDialog(CameraManager *mgr, QWidget *parent = nullptr);

private slots:
    void startDiscovery();
    void startScan();
    void addCandidate(const QString &ip, quint16 httpPort, const QString &model);
    void importSelected();
    void setAllChecked(bool on);

private:
    void setBusy(bool busy);

    struct Candidate {
        QString address;
        quint16 httpPort = 80;
    };

    CameraManager *m_mgr;
    HikDiscovery *m_discovery = nullptr;
    PortScanner *m_scanner = nullptr;
    HikResolver *m_resolver = nullptr;

    QLineEdit *m_from = nullptr;
    QLineEdit *m_to = nullptr;
    QSpinBox *m_httpPort = nullptr;
    QSpinBox *m_rtspPort = nullptr;
    QLineEdit *m_user = nullptr;
    QLineEdit *m_pass = nullptr;
    QLineEdit *m_group = nullptr;
    QSpinBox *m_fallback = nullptr;
    QTableWidget *m_table = nullptr;
    QProgressBar *m_progress = nullptr;
    QLabel *m_status = nullptr;
    QPushButton *m_btnDiscover = nullptr;
    QPushButton *m_btnScan = nullptr;
    QPushButton *m_btnImport = nullptr;

    QList<Candidate> m_candidates;   // строка таблицы i == m_candidates[i]
    QSet<QString> m_existing;        // уже добавленные устройства (по IP)
    QList<int> m_importRows;
    QList<CameraEntry> m_pending;
    QList<int> m_pendingRows;
    int m_failed = 0;
    int m_devicesOk = 0;
    QString m_curUser;
    QString m_curPass;
    quint16 m_curRtsp = 554;
};
