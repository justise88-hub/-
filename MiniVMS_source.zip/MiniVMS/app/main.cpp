#include <QApplication>

#include "app/camera_manager.h"
#include "app/main_window.h"
#include "app/theme.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setOrganizationName(QStringLiteral("MiniVMS"));
    QCoreApplication::setApplicationName(QStringLiteral("MiniVMS"));

    app.setStyle(QStringLiteral("Fusion"));
    app.setStyleSheet(appStyleSheet());

    CameraManager manager;       // читает камеры из настроек и запускает запись
    MainWindow window(&manager);
    window.show();

    return app.exec();
}
