#pragma once

#include <QHash>
#include <QList>
#include <QObject>
#include <QString>
#include <QStringList>

#include "core/camera_worker.h"

class QTimer;

struct CameraEntry {
    QString id;
    QString name;
    QString group;
    QString url;       // основной поток: по нему идёт запись в архив
    QString liveUrl;   // дополнительный поток (меньше разрешение) для мозаики; может быть пустым
    bool record = true;   // вести ли непрерывную запись
};

inline QString stateText(CameraWorker::State s)
{
    switch (s) {
    case CameraWorker::State::Recording:    return QStringLiteral("Запись идёт");
    case CameraWorker::State::Connecting:   return QStringLiteral("Подключение…");
    case CameraWorker::State::Reconnecting: return QStringLiteral("Нет связи, переподключение…");
    case CameraWorker::State::Stopped:      break;
    }
    return QStringLiteral("Остановлено");
}

// Список камер (хранится в QSettings) и их рекордеры (CameraWorker).
// Рекордеры запускаются по очереди (по одному каждые ~120 мс), чтобы 200 камер
// не подключались одновременно и не устроили «шторм» подключений.
class CameraManager : public QObject {
    Q_OBJECT
public:
    explicit CameraManager(QObject *parent = nullptr);
    ~CameraManager() override;

    QString storageRoot() const { return m_storageRoot; }
    QString dbPath() const { return m_storageRoot + QStringLiteral("/index.sqlite"); }

    const QList<CameraEntry> &cameras() const { return m_cameras; }
    const CameraEntry *find(const QString &id) const;
    CameraWorker::State stateOf(const QString &id) const;

    QString add(CameraEntry e);                 // возвращает сгенерированный id
    void addMany(QList<CameraEntry> list);      // пакетное добавление: одно сохранение, один сигнал
    void update(const CameraEntry &e);
    void remove(const QString &id);
    void shutdown();                            // остановить все рекордеры

signals:
    void camerasChanged();
    void cameraStateChanged(const QString &id, CameraWorker::State state);
    void cameraError(const QString &id, const QString &message);

private:
    void load();
    void save() const;
    void syncWorker(const CameraEntry &e);
    void stopWorker(const QString &id);
    void startNext();

    QList<CameraEntry> m_cameras;
    QHash<QString, CameraWorker *> m_workers;
    QHash<QString, CameraWorker::State> m_states;
    QStringList m_startQueue;
    QTimer *m_startTimer = nullptr;
    QString m_storageRoot;
};
