#pragma once

#include <QWidget>

#include "core/camera_worker.h"

class CameraManager;
class QPushButton;
class QTableWidget;

// Управление камерами: добавить, изменить, удалить, посмотреть состояние записи.
class DevicesPage : public QWidget {
    Q_OBJECT
public:
    explicit DevicesPage(CameraManager *mgr, QWidget *parent = nullptr);

private slots:
    void rebuild();
    void updateState(const QString &id, CameraWorker::State state);
    void addCamera();
    void editCamera();
    void removeCamera();
    void updateButtons();

private:
    QString currentId() const;

    CameraManager *m_mgr;
    QTableWidget *m_table = nullptr;
    QPushButton *m_edit = nullptr;
    QPushButton *m_remove = nullptr;
};
