#include "app/devices_page.h"
#include "app/camera_manager.h"
#include "app/hikvision_import_dialog.h"
#include "app/icsee_import_dialog.h"
#include "app/onvif_import_dialog.h"

#include <QCheckBox>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLineEdit>
#include <QMessageBox>
#include <QPushButton>
#include <QRegularExpression>
#include <QTableWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

class CameraDialog : public QDialog {
public:
    CameraDialog(const CameraEntry &base, const QStringList &groups, QWidget *parent)
        : QDialog(parent), m_base(base)
    {
        setWindowTitle(base.id.isEmpty() ? QStringLiteral("Добавить камеру")
                                         : QStringLiteral("Изменить камеру"));
        setMinimumWidth(480);

        m_name = new QLineEdit(base.name, this);
        m_group = new QComboBox(this);
        m_group->setEditable(true);
        m_group->addItems(groups);
        m_group->setCurrentText(base.group);
        m_url = new QLineEdit(base.url, this);
        m_url->setPlaceholderText(
            QStringLiteral("rtsp://логин:пароль@192.168.1.64:554/Streaming/Channels/101"));
        m_liveUrl = new QLineEdit(base.liveUrl, this);
        m_liveUrl->setPlaceholderText(QStringLiteral("необязательно: поток меньшего разрешения для мозаики"));
        m_record = new QCheckBox(QStringLiteral("Вести непрерывную запись в архив"), this);
        m_record->setChecked(base.record);

        auto *form = new QFormLayout;
        form->addRow(QStringLiteral("Название"), m_name);
        form->addRow(QStringLiteral("Группа"), m_group);
        form->addRow(QStringLiteral("Адрес потока"), m_url);
        form->addRow(QStringLiteral("Адрес подпотока"), m_liveUrl);
        form->addRow(QString(), m_record);

        auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
        connect(buttons, &QDialogButtonBox::accepted, this, &QDialog::accept);
        connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);

        auto *lay = new QVBoxLayout(this);
        lay->addLayout(form);
        lay->addWidget(buttons);
    }

    CameraEntry entry() const
    {
        CameraEntry e = m_base;
        e.name = m_name->text().trimmed();
        e.group = m_group->currentText().trimmed();
        e.url = m_url->text().trimmed();
        e.liveUrl = m_liveUrl->text().trimmed();
        e.record = m_record->isChecked();
        return e;
    }

    void accept() override
    {
        const QUrl u(m_url->text().trimmed());
        if (m_name->text().trimmed().isEmpty() || !u.isValid() || u.scheme().isEmpty()) {
            QMessageBox::warning(this, QStringLiteral("Камера"),
                QStringLiteral("Укажите название и корректный адрес потока, например rtsp://…"));
            return;
        }
        QDialog::accept();
    }

private:
    CameraEntry m_base;
    QLineEdit *m_name = nullptr;
    QComboBox *m_group = nullptr;
    QLineEdit *m_url = nullptr;
    QLineEdit *m_liveUrl = nullptr;
    QCheckBox *m_record = nullptr;
};

QStringList groupsOf(const CameraManager *mgr)
{
    QStringList g;
    for (const CameraEntry &e : mgr->cameras())
        if (!e.group.isEmpty() && !g.contains(e.group))
            g << e.group;
    return g;
}

enum Column { ColName, ColGroup, ColAddress, ColState, ColCount };

} // namespace

DevicesPage::DevicesPage(CameraManager *mgr, QWidget *parent) : QWidget(parent), m_mgr(mgr)
{
    auto *add = new QPushButton(QStringLiteral("Добавить"), this);
    m_edit = new QPushButton(QStringLiteral("Изменить"), this);
    m_remove = new QPushButton(QStringLiteral("Удалить"), this);

    auto *top = new QHBoxLayout;
    top->addWidget(add);
    top->addWidget(m_edit);
    top->addWidget(m_remove);
    top->addSpacing(24);
    auto *importBtn = new QPushButton(QStringLiteral("Импорт ONVIF…"), this);
    top->addWidget(importBtn);
    auto *icseeBtn = new QPushButton(QStringLiteral("Добавить iCSee…"), this);
    top->addWidget(icseeBtn);
    auto *hikBtn = new QPushButton(QStringLiteral("Добавить Hikvision / HiWatch…"), this);
    top->addWidget(hikBtn);
    top->addStretch(1);
    connect(hikBtn, &QPushButton::clicked, this, [this] {
        HikvisionImportDialog dlg(m_mgr, this);
        dlg.exec();
    });
    connect(icseeBtn, &QPushButton::clicked, this, [this] {
        IcseeImportDialog dlg(m_mgr, this);
        dlg.exec();
    });
    connect(importBtn, &QPushButton::clicked, this, [this] {
        OnvifImportDialog dlg(m_mgr, this);
        dlg.exec();
    });

    m_table = new QTableWidget(0, ColCount, this);
    m_table->setHorizontalHeaderLabels({QStringLiteral("Название"), QStringLiteral("Группа"),
                                        QStringLiteral("Адрес"), QStringLiteral("Состояние")});
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->verticalHeader()->setVisible(false);
    m_table->horizontalHeader()->setSectionResizeMode(ColAddress, QHeaderView::Stretch);
    m_table->setColumnWidth(ColName, 220);
    m_table->setColumnWidth(ColGroup, 160);
    m_table->setColumnWidth(ColState, 240);

    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(12, 12, 12, 12);
    lay->addLayout(top);
    lay->addWidget(m_table, 1);

    connect(add, &QPushButton::clicked, this, &DevicesPage::addCamera);
    connect(m_edit, &QPushButton::clicked, this, &DevicesPage::editCamera);
    connect(m_remove, &QPushButton::clicked, this, &DevicesPage::removeCamera);
    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this] { editCamera(); });
    connect(m_table, &QTableWidget::itemSelectionChanged, this, &DevicesPage::updateButtons);
    connect(m_mgr, &CameraManager::camerasChanged, this, &DevicesPage::rebuild);
    connect(m_mgr, &CameraManager::cameraStateChanged, this, &DevicesPage::updateState);

    rebuild();
}

QString DevicesPage::currentId() const
{
    const int row = m_table->currentRow();
    if (row < 0)
        return {};
    const QTableWidgetItem *it = m_table->item(row, ColName);
    return it ? it->data(Qt::UserRole).toString() : QString();
}

void DevicesPage::updateButtons()
{
    const bool has = !currentId().isEmpty();
    m_edit->setEnabled(has);
    m_remove->setEnabled(has);
}

void DevicesPage::rebuild()
{
    const QString keep = currentId();
    m_table->setRowCount(0);

    for (const CameraEntry &e : m_mgr->cameras()) {
        const int row = m_table->rowCount();
        m_table->insertRow(row);

        auto *name = new QTableWidgetItem(e.name);
        name->setData(Qt::UserRole, e.id);
        m_table->setItem(row, ColName, name);
        m_table->setItem(row, ColGroup, new QTableWidgetItem(e.group));

        QUrl shown(e.url);                                   // логин и пароль не показываем
        // у iCSee пароль передаётся в самом пути (password=...), его тоже скрываем
        QString addr = shown.toString(QUrl::RemoveUserInfo);
        addr.replace(QRegularExpression(QStringLiteral("password=[^&]*")), QStringLiteral("password=***"));
        m_table->setItem(row, ColAddress, new QTableWidgetItem(addr));

        const QString st = e.record ? stateText(m_mgr->stateOf(e.id))
                                    : QStringLiteral("Запись выключена");
        m_table->setItem(row, ColState, new QTableWidgetItem(st));

        if (e.id == keep)
            m_table->selectRow(row);
    }
    updateButtons();
}

void DevicesPage::updateState(const QString &id, CameraWorker::State state)
{
    for (int row = 0; row < m_table->rowCount(); ++row) {
        if (m_table->item(row, ColName)->data(Qt::UserRole).toString() == id) {
            const CameraEntry *e = m_mgr->find(id);
            const QString st = (e && !e->record) ? QStringLiteral("Запись выключена") : stateText(state);
            m_table->item(row, ColState)->setText(st);
            return;
        }
    }
}

void DevicesPage::addCamera()
{
    CameraEntry base;
    CameraDialog dlg(base, groupsOf(m_mgr), this);
    if (dlg.exec() == QDialog::Accepted)
        m_mgr->add(dlg.entry());
}

void DevicesPage::editCamera()
{
    const CameraEntry *cur = m_mgr->find(currentId());
    if (!cur)
        return;
    CameraDialog dlg(*cur, groupsOf(m_mgr), this);
    if (dlg.exec() == QDialog::Accepted)
        m_mgr->update(dlg.entry());
}

void DevicesPage::removeCamera()
{
    const CameraEntry *cur = m_mgr->find(currentId());
    if (!cur)
        return;
    const auto answer = QMessageBox::question(this, QStringLiteral("Удаление камеры"),
        QStringLiteral("Удалить камеру «%1»?\nУже записанные файлы архива останутся на диске.").arg(cur->name));
    if (answer == QMessageBox::Yes)
        m_mgr->remove(cur->id);
}
