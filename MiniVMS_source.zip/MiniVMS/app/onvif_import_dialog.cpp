#include "app/onvif_import_dialog.h"

#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QHostAddress>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QSpinBox>
#include <QTableWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

enum Column { ColCheck, ColAddress, ColName, ColState, ColCount };

constexpr int kMaxRange = 2048;

bool parseIpv4(const QString &s, quint32 *out)
{
    QHostAddress a;
    if (!a.setAddress(s.trimmed()) || a.protocol() != QAbstractSocket::IPv4Protocol)
        return false;
    *out = a.toIPv4Address();
    return true;
}

} // namespace

OnvifImportDialog::OnvifImportDialog(CameraManager *mgr, QWidget *parent) : QDialog(parent), m_mgr(mgr)
{
    setWindowTitle(QStringLiteral("Импорт камер по ONVIF"));
    resize(940, 640);

    for (const CameraEntry &e : m_mgr->cameras())
        m_existingHosts.insert(QUrl(e.url).host());

    m_discovery = new OnvifDiscovery(this);
    m_scanner = new OnvifScanner(this);
    m_resolver = new OnvifResolver(this);

    // ---- поиск ----
    auto *findBox = new QGroupBox(QStringLiteral("1. Поиск камер"), this);
    auto *findLay = new QHBoxLayout(findBox);
    m_btnDiscover = new QPushButton(QStringLiteral("Найти в своей сети"), findBox);
    m_from = new QLineEdit(findBox);
    m_from->setPlaceholderText(QStringLiteral("192.168.1.1"));
    m_to = new QLineEdit(findBox);
    m_to->setPlaceholderText(QStringLiteral("192.168.1.254"));
    m_port = new QSpinBox(findBox);
    m_port->setRange(1, 65535);
    m_port->setValue(80);
    m_port->setToolTip(QStringLiteral("Порт ONVIF: обычно 80; у камер Xiongmai/iCSee — 8899"));
    m_btnScan = new QPushButton(QStringLiteral("Сканировать диапазон"), findBox);
    findLay->addWidget(m_btnDiscover);
    findLay->addSpacing(20);
    findLay->addWidget(new QLabel(QStringLiteral("Диапазон IP:"), findBox));
    findLay->addWidget(m_from);
    findLay->addWidget(new QLabel(QStringLiteral("—"), findBox));
    findLay->addWidget(m_to);
    findLay->addWidget(new QLabel(QStringLiteral("порт"), findBox));
    findLay->addWidget(m_port);
    findLay->addWidget(m_btnScan);

    // ---- доступ ----
    auto *authBox = new QGroupBox(QStringLiteral("2. Общие логин и пароль камер"), this);
    auto *authLay = new QHBoxLayout(authBox);
    m_user = new QLineEdit(QStringLiteral("admin"), authBox);
    m_pass = new QLineEdit(authBox);
    m_pass->setEchoMode(QLineEdit::Password);
    m_group = new QLineEdit(authBox);
    m_group->setPlaceholderText(QStringLiteral("например, Склад"));
    authLay->addWidget(new QLabel(QStringLiteral("Логин:"), authBox));
    authLay->addWidget(m_user);
    authLay->addWidget(new QLabel(QStringLiteral("Пароль:"), authBox));
    authLay->addWidget(m_pass);
    authLay->addWidget(new QLabel(QStringLiteral("Группа:"), authBox));
    authLay->addWidget(m_group);

    // ---- таблица ----
    m_table = new QTableWidget(0, ColCount, this);
    m_table->setHorizontalHeaderLabels({QString(), QStringLiteral("Адрес"),
                                        QStringLiteral("Имя / модель"), QStringLiteral("Состояние")});
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionMode(QAbstractItemView::NoSelection);
    m_table->verticalHeader()->setVisible(false);
    m_table->setColumnWidth(ColCheck, 34);
    m_table->setColumnWidth(ColAddress, 150);
    m_table->setColumnWidth(ColName, 300);
    m_table->horizontalHeader()->setSectionResizeMode(ColState, QHeaderView::Stretch);

    auto *selAll = new QPushButton(QStringLiteral("Выбрать все"), this);
    auto *selNone = new QPushButton(QStringLiteral("Снять выбор"), this);
    auto *selRow = new QHBoxLayout;
    selRow->addWidget(new QLabel(QStringLiteral("3. Найденные устройства"), this));
    selRow->addStretch(1);
    selRow->addWidget(selAll);
    selRow->addWidget(selNone);

    // ---- низ ----
    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1);
    m_progress->setValue(0);
    m_status = new QLabel(QStringLiteral("Нажмите «Найти в своей сети» или задайте диапазон IP."), this);
    m_btnImport = new QPushButton(QStringLiteral("Добавить выбранные"), this);
    auto *close = new QPushButton(QStringLiteral("Закрыть"), this);

    auto *bottom = new QHBoxLayout;
    bottom->addWidget(m_progress, 1);
    bottom->addWidget(m_btnImport);
    bottom->addWidget(close);

    auto *root = new QVBoxLayout(this);
    root->addWidget(findBox);
    root->addWidget(authBox);
    root->addLayout(selRow);
    root->addWidget(m_table, 1);
    root->addWidget(m_status);
    root->addLayout(bottom);

    // ---- сигналы ----
    connect(m_btnDiscover, &QPushButton::clicked, this, &OnvifImportDialog::startDiscovery);
    connect(m_btnScan, &QPushButton::clicked, this, &OnvifImportDialog::startScan);
    connect(m_btnImport, &QPushButton::clicked, this, &OnvifImportDialog::importSelected);
    connect(selAll, &QPushButton::clicked, this, [this] { setAllChecked(true); });
    connect(selNone, &QPushButton::clicked, this, [this] { setAllChecked(false); });
    connect(close, &QPushButton::clicked, this, &QDialog::accept);

    connect(m_discovery, &OnvifDiscovery::deviceFound, this, &OnvifImportDialog::addDevice);
    connect(m_discovery, &OnvifDiscovery::finished, this, [this] {
        m_progress->setRange(0, 1);
        m_progress->setValue(1);
        m_status->setText(QStringLiteral("Поиск завершён. Найдено устройств: %1").arg(m_devices.size()));
        setBusy(false);
    });

    connect(m_scanner, &OnvifScanner::deviceFound, this, &OnvifImportDialog::addDevice);
    connect(m_scanner, &OnvifScanner::progress, this, [this](int done, int total) {
        m_progress->setRange(0, total);
        m_progress->setValue(done);
        m_status->setText(QStringLiteral("Сканирование: %1 из %2, найдено: %3")
                              .arg(done).arg(total).arg(m_devices.size()));
    });
    connect(m_scanner, &OnvifScanner::finished, this, [this] {
        m_status->setText(QStringLiteral("Сканирование завершено. Найдено устройств: %1").arg(m_devices.size()));
        setBusy(false);
    });

    connect(m_resolver, &OnvifResolver::progress, this, [this](int done, int total) {
        m_progress->setRange(0, total);
        m_progress->setValue(done);
        m_status->setText(QStringLiteral("Опрос камер: %1 из %2").arg(done).arg(total));
    });
    connect(m_resolver, &OnvifResolver::resolved, this, [this](int i, const OnvifStreams &s) {
        const int row = m_importRows.at(i);
        if (!s.ok) {
            ++m_failed;
            m_table->item(row, ColState)->setText(s.error);
            return;
        }
        CameraEntry e;
        e.name = displayName(row);
        e.group = m_group->text().trimmed();
        e.url = s.mainUrl;
        e.liveUrl = s.subUrl;
        e.record = true;
        m_pending.append(e);
        m_pendingRows.append(row);
        m_table->item(row, ColState)->setText(
            s.subUrl.isEmpty() ? QStringLiteral("Получен 1 поток") : QStringLiteral("Получены основной поток и подпоток"));
    });
    connect(m_resolver, &OnvifResolver::finished, this, [this] {
        if (!m_pending.isEmpty())
            m_mgr->addMany(m_pending);   // одно сохранение и один пересбор интерфейса на всех
        for (int row : std::as_const(m_pendingRows)) {
            m_table->item(row, ColState)->setText(QStringLiteral("Добавлена"));
            m_table->item(row, ColCheck)->setCheckState(Qt::Unchecked);
            m_table->item(row, ColCheck)->setFlags(Qt::NoItemFlags);
            m_existingHosts.insert(m_devices.at(row).address);
        }
        m_status->setText(QStringLiteral("Добавлено камер: %1, с ошибкой: %2%3")
                              .arg(m_pending.size()).arg(m_failed)
                              .arg(m_failed ? QStringLiteral(" (исправьте логин/пароль и повторите)") : QString()));
        m_pending.clear();
        m_pendingRows.clear();
        setBusy(false);
    });
}

QString OnvifImportDialog::displayName(int row) const
{
    const OnvifDevice &d = m_devices.at(row);
    QString base = d.name.isEmpty() ? d.hardware : d.name;
    return base.isEmpty() ? d.address : QStringLiteral("%1 (%2)").arg(base, d.address);
}

void OnvifImportDialog::addDevice(const OnvifDevice &dev)
{
    for (const OnvifDevice &d : std::as_const(m_devices))
        if (d.address == dev.address)
            return;

    const int row = m_table->rowCount();
    m_table->insertRow(row);
    m_devices.append(dev);

    const bool exists = m_existingHosts.contains(dev.address);

    auto *chk = new QTableWidgetItem;
    chk->setFlags(exists ? Qt::NoItemFlags : (Qt::ItemIsUserCheckable | Qt::ItemIsEnabled));
    chk->setCheckState(exists ? Qt::Unchecked : Qt::Checked);
    m_table->setItem(row, ColCheck, chk);
    m_table->setItem(row, ColAddress, new QTableWidgetItem(dev.address));

    QString title = dev.name;
    if (!dev.hardware.isEmpty())
        title += title.isEmpty() ? dev.hardware : QStringLiteral(" (%1)").arg(dev.hardware);
    m_table->setItem(row, ColName, new QTableWidgetItem(title));
    m_table->setItem(row, ColState,
                     new QTableWidgetItem(exists ? QStringLiteral("Уже добавлена") : QStringLiteral("Найдена")));
}

void OnvifImportDialog::setAllChecked(bool on)
{
    for (int row = 0; row < m_table->rowCount(); ++row) {
        QTableWidgetItem *it = m_table->item(row, ColCheck);
        if (it->flags() & Qt::ItemIsUserCheckable)
            it->setCheckState(on ? Qt::Checked : Qt::Unchecked);
    }
}

void OnvifImportDialog::setBusy(bool busy)
{
    m_btnDiscover->setEnabled(!busy);
    m_btnScan->setEnabled(!busy);
    m_btnImport->setEnabled(!busy);
}

void OnvifImportDialog::startDiscovery()
{
    setBusy(true);
    m_progress->setRange(0, 0);   // «бегущая» полоса
    m_status->setText(QStringLiteral("Поиск камер в сети…"));
    m_discovery->start(4000);
}

void OnvifImportDialog::startScan()
{
    quint32 a = 0, b = 0;
    if (!parseIpv4(m_from->text(), &a) || !parseIpv4(m_to->text(), &b) || b < a) {
        QMessageBox::warning(this, windowTitle(), QStringLiteral("Укажите корректный диапазон IPv4-адресов."));
        return;
    }
    if (quint64(b) - a + 1 > kMaxRange) {
        QMessageBox::warning(this, windowTitle(),
            QStringLiteral("Слишком большой диапазон: максимум %1 адресов за раз.").arg(kMaxRange));
        return;
    }
    setBusy(true);
    m_progress->setRange(0, int(b - a + 1));
    m_progress->setValue(0);
    m_scanner->start(a, b, quint16(m_port->value()), 64);
}

void OnvifImportDialog::importSelected()
{
    if (m_user->text().trimmed().isEmpty()) {
        QMessageBox::warning(this, windowTitle(), QStringLiteral("Укажите логин камер."));
        return;
    }

    m_importRows.clear();
    m_pending.clear();
    m_pendingRows.clear();
    m_failed = 0;

    QList<OnvifRequest> requests;
    for (int row = 0; row < m_table->rowCount(); ++row) {
        const QTableWidgetItem *chk = m_table->item(row, ColCheck);
        if (!(chk->flags() & Qt::ItemIsUserCheckable) || chk->checkState() != Qt::Checked)
            continue;
        requests.append({m_devices.at(row).xaddr, m_user->text().trimmed(), m_pass->text()});
        m_importRows.append(row);
        m_table->item(row, ColState)->setText(QStringLiteral("Запрос…"));
    }
    if (requests.isEmpty()) {
        QMessageBox::information(this, windowTitle(), QStringLiteral("Отметьте камеры для добавления."));
        return;
    }

    setBusy(true);
    m_progress->setRange(0, int(requests.size()));
    m_progress->setValue(0);
    m_resolver->start(requests, 8);   // одновременно опрашиваем 8 камер
}
