#include "app/events_page.h"

#include <QDateTime>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QPushButton>
#include <QTableWidget>
#include <QVBoxLayout>

EventsPage::EventsPage(QWidget *parent) : QWidget(parent)
{
    auto *clear = new QPushButton(QStringLiteral("Очистить"), this);
    auto *top = new QHBoxLayout;
    top->addWidget(clear);
    top->addStretch(1);

    m_table = new QTableWidget(0, 3, this);
    m_table->setHorizontalHeaderLabels(
        {QStringLiteral("Время"), QStringLiteral("Камера"), QStringLiteral("Событие")});
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->verticalHeader()->setVisible(false);
    m_table->horizontalHeader()->setSectionResizeMode(2, QHeaderView::Stretch);
    m_table->setColumnWidth(0, 170);
    m_table->setColumnWidth(1, 220);

    auto *lay = new QVBoxLayout(this);
    lay->setContentsMargins(12, 12, 12, 12);
    lay->addLayout(top);
    lay->addWidget(m_table, 1);

    connect(clear, &QPushButton::clicked, this, [this] { m_table->setRowCount(0); });
}

void EventsPage::addEvent(const QString &camera, const QString &text)
{
    m_table->insertRow(0);   // новые события сверху
    m_table->setItem(0, 0, new QTableWidgetItem(
        QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss"))));
    m_table->setItem(0, 1, new QTableWidgetItem(camera));
    m_table->setItem(0, 2, new QTableWidgetItem(text));

    while (m_table->rowCount() > 1000)   // не даём журналу расти бесконечно
        m_table->removeRow(m_table->rowCount() - 1);
}
