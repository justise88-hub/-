#include "app/camera_manager.h"

#include <QDir>
#include <QSettings>
#include <QStandardPaths>
#include <QTimer>
#include <QUuid>

namespace {
QString newId()
{
    return QStringLiteral("cam") + QUuid::createUuid().toString(QUuid::Id128).left(8);
}
} // namespace

CameraManager::CameraManager(QObject *parent) : QObject(parent)
{
    QSettings s;
    m_storageRoot = s.value(QStringLiteral("storage/root"),
                            QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)
                                + QStringLiteral("/MiniVMS Archive")).toString();
    QDir().mkpath(m_storageRoot);

    m_startTimer = new QTimer(this);
    m_startTimer->setInterval(120);
    connect(m_startTimer, &QTimer::timeout, this, &CameraManager::startNext);

    load();
    for (const CameraEntry &e : std::as_const(m_cameras))
        syncWorker(e);
}

CameraManager::~CameraManager()
{
    shutdown();
}

const CameraEntry *CameraManager::find(const QString &id) const
{
    for (const CameraEntry &e : m_cameras)
        if (e.id == id)
            return &e;
    return nullptr;
}

CameraWorker::State CameraManager::stateOf(const QString &id) const
{
    return m_states.value(id, CameraWorker::State::Stopped);
}

QString CameraManager::add(CameraEntry e)
{
    e.id = newId();
    m_cameras.append(e);
    save();
    syncWorker(e);
    emit camerasChanged();
    return e.id;
}

void CameraManager::addMany(QList<CameraEntry> list)
{
    if (list.isEmpty())
        return;
    for (CameraEntry &e : list)
        e.id = newId();
    m_cameras.append(list);
    save();                                  // один раз на всю пачку
    for (const CameraEntry &e : std::as_const(list))
        syncWorker(e);
    emit camerasChanged();
}

void CameraManager::update(const CameraEntry &e)
{
    for (CameraEntry &old : m_cameras) {
        if (old.id == e.id) {
            old = e;
            save();
            syncWorker(e);
            emit camerasChanged();
            return;
        }
    }
}

void CameraManager::remove(const QString &id)
{
    stopWorker(id);
    for (int i = 0; i < m_cameras.size(); ++i) {
        if (m_cameras[i].id == id) {
            m_cameras.removeAt(i);
            break;
        }
    }
    m_states.remove(id);
    save();
    emit camerasChanged();
}

void CameraManager::shutdown()
{
    m_startQueue.clear();
    m_startTimer->stop();
    for (CameraWorker *w : std::as_const(m_workers))
        w->stop();
    for (CameraWorker *w : std::as_const(m_workers))
        w->wait();
    qDeleteAll(m_workers);
    m_workers.clear();
}

void CameraManager::load()
{
    QSettings s;
    const int n = s.beginReadArray(QStringLiteral("cameras"));
    for (int i = 0; i < n; ++i) {
        s.setArrayIndex(i);
        CameraEntry e;
        e.id = s.value(QStringLiteral("id")).toString();
        e.name = s.value(QStringLiteral("name")).toString();
        e.group = s.value(QStringLiteral("group")).toString();
        e.url = s.value(QStringLiteral("url")).toString();
        e.liveUrl = s.value(QStringLiteral("liveUrl")).toString();
        e.record = s.value(QStringLiteral("record"), true).toBool();
        if (!e.id.isEmpty())
            m_cameras.append(e);
    }
    s.endArray();
}

void CameraManager::save() const
{
    QSettings s;
    s.remove(QStringLiteral("cameras"));
    s.beginWriteArray(QStringLiteral("cameras"), int(m_cameras.size()));
    for (int i = 0; i < m_cameras.size(); ++i) {
        s.setArrayIndex(i);
        const CameraEntry &e = m_cameras.at(i);
        s.setValue(QStringLiteral("id"), e.id);
        s.setValue(QStringLiteral("name"), e.name);
        s.setValue(QStringLiteral("group"), e.group);
        s.setValue(QStringLiteral("url"), e.url);          // ВНИМАНИЕ: пароль хранится открытым текстом
        s.setValue(QStringLiteral("liveUrl"), e.liveUrl);
        s.setValue(QStringLiteral("record"), e.record);
    }
    s.endArray();
}

void CameraManager::stopWorker(const QString &id)
{
    m_startQueue.removeAll(id);
    if (CameraWorker *w = m_workers.take(id)) {
        w->stop();
        w->wait();
        delete w;
    }
}

void CameraManager::syncWorker(const CameraEntry &e)
{
    stopWorker(e.id);
    if (!e.record) {
        m_states.insert(e.id, CameraWorker::State::Stopped);
        emit cameraStateChanged(e.id, CameraWorker::State::Stopped);
        return;
    }
    // запуск не сразу, а через очередь
    m_states.insert(e.id, CameraWorker::State::Connecting);
    emit cameraStateChanged(e.id, CameraWorker::State::Connecting);
    m_startQueue.append(e.id);
    if (!m_startTimer->isActive())
        m_startTimer->start();
}

void CameraManager::startNext()
{
    if (m_startQueue.isEmpty()) {
        m_startTimer->stop();
        return;
    }
    const QString id = m_startQueue.takeFirst();
    const CameraEntry *e = find(id);
    if (!e || !e->record || m_workers.contains(id))
        return;

    CameraConfig cfg;
    cfg.id = e->id;
    cfg.name = e->name;
    cfg.url = e->url;
    cfg.storageRoot = m_storageRoot;
    cfg.dbPath = dbPath();

    auto *w = new CameraWorker(cfg, this);
    connect(w, &CameraWorker::stateChanged, this,
            [this](const QString &cid, CameraWorker::State st) {
                m_states.insert(cid, st);
                emit cameraStateChanged(cid, st);
            });
    connect(w, &CameraWorker::errorOccurred, this, &CameraManager::cameraError);
    m_workers.insert(e->id, w);
    w->startRecording();
}
