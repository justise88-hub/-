#pragma once

// MIME-тип для перетаскивания камеры из списка в ячейку видео
inline constexpr const char *kCameraMime = "application/x-minivms-camera";
