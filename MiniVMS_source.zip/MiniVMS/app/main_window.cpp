#include "app/main_window.h"
#include "app/camera_manager.h"
#include "app/devices_page.h"
#include "app/events_page.h"
#include "app/live_view_page.h"
#include "app/playback_page.h"

#include <QActionGroup>
#include <QCloseEvent>
#include <QDateTime>
#include <QLabel>
#include <QSettings>
#include <QStackedWidget>
#include <QStatusBar>
#include <QTimer>
#include <QToolBar>

MainWindow::MainWindow(CameraManager *mgr, QWidget *parent) : QMainWindow(parent), m_mgr(mgr)
{
    setWindowTitle(QStringLiteral("MiniVMS"));
    resize(1440, 860);
    setMinimumSize(1024, 640);

    // ---- верхняя панель с вкладками ----
    QToolBar *bar = addToolBar(QStringLiteral("Навигация"));
    bar->setMovable(false);
    bar->setFloatable(false);
    bar->setContextMenuPolicy(Qt::PreventContextMenu);

    auto *brand = new QLabel(QStringLiteral("MiniVMS"), bar);
    brand->setObjectName(QStringLiteral("brand"));
    bar->addWidget(brand);

    m_stack = new QStackedWidget(this);
    m_events = new EventsPage(this);

    auto *group = new QActionGroup(this);
    group->setExclusive(true);
    auto addTab = [&](const QString &title, QWidget *page) {
        const int idx = m_stack->addWidget(page);
        QAction *a = bar->addAction(title);
        a->setCheckable(true);
        group->addAction(a);
        connect(a, &QAction::triggered, this, [this, idx] { m_stack->setCurrentIndex(idx); });
        return a;
    };
    QAction *first = addTab(QStringLiteral("Просмотр"), new LiveViewPage(mgr, this));
    addTab(QStringLiteral("Архив"), new PlaybackPage(mgr, this));
    addTab(QStringLiteral("Устройства"), new DevicesPage(mgr, this));
    addTab(QStringLiteral("Журнал"), m_events);
    first->setChecked(true);

    auto *spacer = new QWidget(bar);
    spacer->setObjectName(QStringLiteral("spacer"));
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    bar->addWidget(spacer);

    m_clock = new QLabel(bar);
    m_clock->setObjectName(QStringLiteral("clock"));
    bar->addWidget(m_clock);

    auto *clockTimer = new QTimer(this);
    connect(clockTimer, &QTimer::timeout, this, [this] {
        m_clock->setText(QDateTime::currentDateTime().toString(QStringLiteral("dd.MM.yyyy  HH:mm:ss")));
    });
    clockTimer->start(1000);
    m_clock->setText(QDateTime::currentDateTime().toString(QStringLiteral("dd.MM.yyyy  HH:mm:ss")));

    setCentralWidget(m_stack);

    // ---- строка состояния ----
    m_status = new QLabel(this);
    statusBar()->addPermanentWidget(m_status, 1);
    statusBar()->setSizeGripEnabled(false);

    // ---- журнал и статус реагируют на события рекордеров ----
    connect(mgr, &CameraManager::cameraError, this, [this](const QString &id, const QString &msg) {
        const CameraEntry *e = m_mgr->find(id);
        m_events->addEvent(e ? e->name : id, msg);
    });
    connect(mgr, &CameraManager::cameraStateChanged, this,
            [this](const QString &id, CameraWorker::State s) {
                if (s != CameraWorker::State::Connecting) {
                    const CameraEntry *e = m_mgr->find(id);
                    m_events->addEvent(e ? e->name : id, stateText(s));
                }
                updateStatus();
            });
    connect(mgr, &CameraManager::camerasChanged, this, &MainWindow::updateStatus);

    restoreGeometry(QSettings().value(QStringLiteral("ui/geometry")).toByteArray());
    updateStatus();
}

void MainWindow::updateStatus()
{
    int recording = 0;
    for (const CameraEntry &e : m_mgr->cameras())
        if (m_mgr->stateOf(e.id) == CameraWorker::State::Recording)
            ++recording;

    m_status->setText(QStringLiteral("Камер: %1    Ведётся запись: %2    Архив: %3")
                          .arg(m_mgr->cameras().size())
                          .arg(recording)
                          .arg(m_mgr->storageRoot()));
}

void MainWindow::closeEvent(QCloseEvent *e)
{
    QSettings().setValue(QStringLiteral("ui/geometry"), saveGeometry());
    m_mgr->shutdown();   // корректно закрыть текущие сегменты записи
    QMainWindow::closeEvent(e);
}
