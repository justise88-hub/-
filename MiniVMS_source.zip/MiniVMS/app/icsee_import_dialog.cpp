#include "app/icsee_import_dialog.h"
#include "core/icsee.h"

#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QHostAddress>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QSpinBox>
#include <QTableWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

enum Column { ColCheck, ColAddress, ColState, ColCount };
constexpr int kMaxRange = 2048;

bool parseIpv4(const QString &s, quint32 *out)
{
    QHostAddress a;
    if (!a.setAddress(s.trimmed()) || a.protocol() != QAbstractSocket::IPv4Protocol)
        return false;
    *out = a.toIPv4Address();
    return true;
}

} // namespace

IcseeImportDialog::IcseeImportDialog(CameraManager *mgr, QWidget *parent) : QDialog(parent), m_mgr(mgr)
{
    setWindowTitle(QStringLiteral("Добавить камеры iCSee"));
    resize(820, 600);

    for (const CameraEntry &e : m_mgr->cameras())
        m_existing.insert(QUrl(e.url).host());

    m_scanner = new PortScanner(this);

    // ---- поиск ----
    auto *findBox = new QGroupBox(QStringLiteral("1. Адреса камер"), this);
    auto *findLay = new QHBoxLayout(findBox);
    m_from = new QLineEdit(findBox);
    m_from->setPlaceholderText(QStringLiteral("192.168.1.1"));
    m_to = new QLineEdit(findBox);
    m_to->setPlaceholderText(QStringLiteral("192.168.1.254"));
    m_port = new QSpinBox(findBox);
    m_port->setRange(1, 65535);
    m_port->setValue(554);
    m_port->setToolTip(QStringLiteral("RTSP-порт камеры, по умолчанию 554"));
    m_btnScan = new QPushButton(QStringLiteral("Найти камеры"), findBox);
    findLay->addWidget(new QLabel(QStringLiteral("Диапазон IP:"), findBox));
    findLay->addWidget(m_from);
    findLay->addWidget(new QLabel(QStringLiteral("—"), findBox));
    findLay->addWidget(m_to);
    findLay->addWidget(new QLabel(QStringLiteral("RTSP-порт"), findBox));
    findLay->addWidget(m_port);
    findLay->addWidget(m_btnScan);

    // ---- доступ ----
    auto *authBox = new QGroupBox(QStringLiteral("2. Логин и пароль камер"), this);
    auto *authLay = new QHBoxLayout(authBox);
    m_user = new QLineEdit(QStringLiteral("admin"), authBox);
    m_pass = new QLineEdit(authBox);
    m_pass->setEchoMode(QLineEdit::Password);
    m_pass->setPlaceholderText(QStringLiteral("у новых камер iCSee часто пустой"));
    m_group = new QLineEdit(authBox);
    m_group->setPlaceholderText(QStringLiteral("например, Двор"));
    authLay->addWidget(new QLabel(QStringLiteral("Логин:"), authBox));
    authLay->addWidget(m_user);
    authLay->addWidget(new QLabel(QStringLiteral("Пароль:"), authBox));
    authLay->addWidget(m_pass);
    authLay->addWidget(new QLabel(QStringLiteral("Группа:"), authBox));
    authLay->addWidget(m_group);

    // ---- таблица ----
    m_table = new QTableWidget(0, ColCount, this);
    m_table->setHorizontalHeaderLabels({QString(), QStringLiteral("Адрес"), QStringLiteral("Состояние")});
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionMode(QAbstractItemView::NoSelection);
    m_table->verticalHeader()->setVisible(false);
    m_table->setColumnWidth(ColCheck, 34);
    m_table->setColumnWidth(ColAddress, 200);
    m_table->horizontalHeader()->setSectionResizeMode(ColState, QHeaderView::Stretch);

    auto *selAll = new QPushButton(QStringLiteral("Выбрать все"), this);
    auto *selNone = new QPushButton(QStringLiteral("Снять выбор"), this);
    auto *selRow = new QHBoxLayout;
    selRow->addWidget(new QLabel(QStringLiteral("3. Найденные адреса с открытым RTSP-портом"), this));
    selRow->addStretch(1);
    selRow->addWidget(selAll);
    selRow->addWidget(selNone);

    // ---- низ ----
    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 1);
    m_progress->setValue(0);
    m_status = new QLabel(
        QStringLiteral("Камеры должны быть в вашей сети (по IP). Облачное подключение по серийному номеру не используется."),
        this);
    m_status->setWordWrap(true);
    m_btnAdd = new QPushButton(QStringLiteral("Добавить выбранные"), this);
    auto *close = new QPushButton(QStringLiteral("Закрыть"), this);

    auto *bottom = new QHBoxLayout;
    bottom->addWidget(m_progress, 1);
    bottom->addWidget(m_btnAdd);
    bottom->addWidget(close);

    auto *root = new QVBoxLayout(this);
    root->addWidget(findBox);
    root->addWidget(authBox);
    root->addLayout(selRow);
    root->addWidget(m_table, 1);
    root->addWidget(m_status);
    root->addLayout(bottom);

    // ---- сигналы ----
    connect(m_btnScan, &QPushButton::clicked, this, &IcseeImportDialog::startScan);
    connect(m_btnAdd, &QPushButton::clicked, this, &IcseeImportDialog::addSelected);
    connect(selAll, &QPushButton::clicked, this, [this] { setAllChecked(true); });
    connect(selNone, &QPushButton::clicked, this, [this] { setAllChecked(false); });
    connect(close, &QPushButton::clicked, this, &QDialog::accept);

    connect(m_scanner, &PortScanner::found, this, &IcseeImportDialog::addHost);
    connect(m_scanner, &PortScanner::progress, this, [this](int done, int total) {
        m_progress->setRange(0, total);
        m_progress->setValue(done);
        m_status->setText(QStringLiteral("Проверено %1 из %2, найдено: %3").arg(done).arg(total).arg(m_hosts.size()));
    });
    connect(m_scanner, &PortScanner::finished, this, [this] {
        m_status->setText(QStringLiteral("Поиск завершён. Найдено адресов: %1").arg(m_hosts.size()));
        m_btnScan->setEnabled(true);
        m_btnAdd->setEnabled(true);
    });
}

void IcseeImportDialog::startScan()
{
    quint32 a = 0, b = 0;
    if (!parseIpv4(m_from->text(), &a) || !parseIpv4(m_to->text(), &b) || b < a) {
        QMessageBox::warning(this, windowTitle(), QStringLiteral("Укажите корректный диапазон IPv4-адресов."));
        return;
    }
    if (quint64(b) - a + 1 > kMaxRange) {
        QMessageBox::warning(this, windowTitle(),
            QStringLiteral("Слишком большой диапазон: максимум %1 адресов за раз.").arg(kMaxRange));
        return;
    }
    m_btnScan->setEnabled(false);
    m_btnAdd->setEnabled(false);
    m_progress->setRange(0, int(b - a + 1));
    m_progress->setValue(0);
    m_scanner->start(a, b, quint16(m_port->value()), 64, 800);
}

void IcseeImportDialog::addHost(const QString &ip)
{
    if (m_hosts.contains(ip))
        return;
    const int row = m_table->rowCount();
    m_table->insertRow(row);
    m_hosts.append(ip);

    const bool exists = m_existing.contains(ip);
    auto *chk = new QTableWidgetItem;
    chk->setFlags(exists ? Qt::NoItemFlags : (Qt::ItemIsUserCheckable | Qt::ItemIsEnabled));
    chk->setCheckState(exists ? Qt::Unchecked : Qt::Checked);
    m_table->setItem(row, ColCheck, chk);
    m_table->setItem(row, ColAddress, new QTableWidgetItem(ip));
    m_table->setItem(row, ColState,
                     new QTableWidgetItem(exists ? QStringLiteral("Уже добавлена")
                                                 : QStringLiteral("RTSP-порт открыт")));
}

void IcseeImportDialog::setAllChecked(bool on)
{
    for (int row = 0; row < m_table->rowCount(); ++row) {
        QTableWidgetItem *it = m_table->item(row, ColCheck);
        if (it->flags() & Qt::ItemIsUserCheckable)
            it->setCheckState(on ? Qt::Checked : Qt::Unchecked);
    }
}

void IcseeImportDialog::addSelected()
{
    const QString user = m_user->text().trimmed();
    const QString pass = m_pass->text();
    const QString group = m_group->text().trimmed();
    const quint16 port = quint16(m_port->value());

    QList<CameraEntry> entries;
    QList<int> rows;
    for (int row = 0; row < m_table->rowCount(); ++row) {
        const QTableWidgetItem *chk = m_table->item(row, ColCheck);
        if (!(chk->flags() & Qt::ItemIsUserCheckable) || chk->checkState() != Qt::Checked)
            continue;
        const QString ip = m_hosts.at(row);

        CameraEntry e;
        e.name = QStringLiteral("iCSee %1").arg(ip);
        e.group = group;
        e.url = icseeRtspUrl(ip, port, user, pass, 1, 0);       // основной поток — в архив
        e.liveUrl = icseeRtspUrl(ip, port, user, pass, 1, 1);   // подпоток — в мозаику
        e.record = true;
        entries.append(e);
        rows.append(row);
    }

    if (entries.isEmpty()) {
        QMessageBox::information(this, windowTitle(), QStringLiteral("Отметьте камеры для добавления."));
        return;
    }

    m_mgr->addMany(entries);
    for (int row : rows) {
        m_table->item(row, ColState)->setText(QStringLiteral("Добавлена"));
        m_table->item(row, ColCheck)->setCheckState(Qt::Unchecked);
        m_table->item(row, ColCheck)->setFlags(Qt::NoItemFlags);
        m_existing.insert(m_hosts.at(row));
    }
    m_status->setText(QStringLiteral("Добавлено камер: %1. Состояние записи смотрите на вкладке «Устройства» и в «Журнале».")
                          .arg(entries.size()));
}
