#include "app/video_cell.h"
#include "app/common.h"

#include <QDragEnterEvent>
#include <QDropEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QMediaPlayer>
#include <QMimeData>
#include <QMouseEvent>
#include <QStackedLayout>
#include <QStyle>
#include <QTimer>
#include <QToolButton>
#include <QVBoxLayout>
#include <QVideoWidget>

VideoCell::VideoCell(QWidget *parent) : QFrame(parent)
{
    setAcceptDrops(true);

    auto *bar = new QWidget(this);
    bar->setObjectName(QStringLiteral("cellBar"));
    auto *barLay = new QHBoxLayout(bar);
    barLay->setContentsMargins(0, 0, 0, 0);
    barLay->setSpacing(0);

    m_title = new QLabel(bar);
    m_title->setObjectName(QStringLiteral("cellTitle"));
    m_close = new QToolButton(bar);
    m_close->setText(QStringLiteral("✕"));
    m_close->setToolTip(QStringLiteral("Закрыть камеру"));
    barLay->addWidget(m_title, 1);
    barLay->addWidget(m_close);

    m_placeholder = new QLabel(
        QStringLiteral("Перетащите камеру сюда\nили дважды щёлкните её в списке"), this);
    m_placeholder->setObjectName(QStringLiteral("placeholder"));
    m_placeholder->setAlignment(Qt::AlignCenter);
    m_placeholder->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);

    m_video = new QVideoWidget(this);
    m_video->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);

    m_stack = new QStackedLayout;
    m_stack->addWidget(m_placeholder);
    m_stack->addWidget(m_video);

    auto *root = new QVBoxLayout(this);
    root->setContentsMargins(2, 2, 2, 2);
    root->setSpacing(0);
    root->addWidget(bar);
    root->addLayout(m_stack, 1);

    m_player = new QMediaPlayer(this);
    m_player->setVideoOutput(m_video);

    // Автопереподключение при ошибке или конце потока
    m_retry = new QTimer(this);
    m_retry->setSingleShot(true);
    m_retry->setInterval(3000);
    connect(m_retry, &QTimer::timeout, this, [this] { if (!isEmpty()) restart(); });
    connect(m_player, &QMediaPlayer::errorOccurred, this, [this] { if (!isEmpty()) m_retry->start(); });
    connect(m_player, &QMediaPlayer::mediaStatusChanged, this, [this](QMediaPlayer::MediaStatus st) {
        if (!isEmpty() && (st == QMediaPlayer::EndOfMedia || st == QMediaPlayer::InvalidMedia))
            m_retry->start();
    });

    connect(m_close, &QToolButton::clicked, this, &VideoCell::clear);

    // QVideoWidget перехватывает мышь, поэтому клики ловим фильтром событий
    m_video->installEventFilter(this);
    m_placeholder->installEventFilter(this);
}

void VideoCell::play(const QString &cameraId, const QString &title, const QUrl &url)
{
    m_cameraId = cameraId;
    m_url = url;
    m_title->setText(title);
    m_stack->setCurrentWidget(m_video);
    restart();
}

void VideoCell::setTitle(const QString &title)
{
    if (!isEmpty())
        m_title->setText(title);
}

void VideoCell::clear()
{
    m_retry->stop();
    m_player->stop();
    m_player->setSource(QUrl());
    m_cameraId.clear();
    m_url.clear();
    m_title->clear();
    m_stack->setCurrentWidget(m_placeholder);
}

void VideoCell::setSelected(bool on)
{
    setProperty("selected", on);
    style()->unpolish(this);
    style()->polish(this);
    update();
}

void VideoCell::restart()
{
    m_player->stop();
    m_player->setSource(QUrl());
    m_player->setSource(m_url);
    m_player->play();
}

bool VideoCell::eventFilter(QObject *obj, QEvent *e)
{
    if (obj == m_video || obj == m_placeholder) {
        if (e->type() == QEvent::MouseButtonPress)
            emit clicked(this);
        else if (e->type() == QEvent::MouseButtonDblClick)
            emit doubleClicked(this);
    }
    return QFrame::eventFilter(obj, e);
}

void VideoCell::mousePressEvent(QMouseEvent *e)
{
    emit clicked(this);
    QFrame::mousePressEvent(e);
}

void VideoCell::mouseDoubleClickEvent(QMouseEvent *e)
{
    emit doubleClicked(this);
    QFrame::mouseDoubleClickEvent(e);
}

void VideoCell::dragEnterEvent(QDragEnterEvent *e)
{
    if (e->mimeData()->hasFormat(QString::fromLatin1(kCameraMime)))
        e->acceptProposedAction();
}

void VideoCell::dropEvent(QDropEvent *e)
{
    const QByteArray data = e->mimeData()->data(QString::fromLatin1(kCameraMime));
    if (data.isEmpty())
        return;
    e->acceptProposedAction();
    emit cameraDropped(this, QString::fromUtf8(data));
}
