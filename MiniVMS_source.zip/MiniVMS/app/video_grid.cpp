#include "app/video_grid.h"
#include "app/camera_manager.h"
#include "app/video_cell.h"

#include <QGridLayout>
#include <QUrl>
#include <cmath>

namespace { constexpr int kMaxCells = 16; }

VideoGrid::VideoGrid(CameraManager *mgr, QWidget *parent) : QWidget(parent), m_mgr(mgr)
{
    m_grid = new QGridLayout(this);
    m_grid->setContentsMargins(0, 0, 0, 0);
    m_grid->setSpacing(3);

    for (int i = 0; i < kMaxCells; ++i) {
        auto *cell = new VideoCell(this);
        connect(cell, &VideoCell::clicked, this, &VideoGrid::select);
        connect(cell, &VideoCell::doubleClicked, this, &VideoGrid::toggleMaximize);
        connect(cell, &VideoCell::cameraDropped, this, [this](VideoCell *c, const QString &id) {
            placeCamera(c, id);
            select(c);
        });
        m_cells.append(cell);
    }

    connect(m_mgr, &CameraManager::camerasChanged, this, &VideoGrid::refreshCells);

    applyLayout();
    select(m_cells.first());
}

void VideoGrid::setLayoutCount(int n)
{
    if (n != 1 && n != 4 && n != 9 && n != 16)
        return;
    m_count = n;
    m_maximized = nullptr;

    for (int i = n; i < m_cells.size(); ++i)   // скрытые ячейки не должны качать видео
        m_cells[i]->clear();

    applyLayout();
    if (m_cells.indexOf(m_selected) >= n)
        select(m_cells.first());
    refreshCells();   // 1×1 переключает камеру на основной поток, остальные раскладки — на подпоток
}

void VideoGrid::applyLayout()
{
    for (VideoCell *c : std::as_const(m_cells))
        m_grid->removeWidget(c);
    for (int i = 0; i < 4; ++i) {
        m_grid->setRowStretch(i, 0);
        m_grid->setColumnStretch(i, 0);
    }

    if (m_maximized) {
        for (VideoCell *c : std::as_const(m_cells))
            c->setVisible(c == m_maximized);
        m_grid->addWidget(m_maximized, 0, 0);
        m_grid->setRowStretch(0, 1);
        m_grid->setColumnStretch(0, 1);
        return;
    }

    const int cols = int(std::lround(std::sqrt(double(m_count))));   // 1, 2, 3, 4
    for (int i = 0; i < m_cells.size(); ++i) {
        VideoCell *c = m_cells[i];
        if (i < m_count) {
            m_grid->addWidget(c, i / cols, i % cols);
            c->show();
        } else {
            c->hide();
        }
    }
    for (int i = 0; i < cols; ++i) {
        m_grid->setRowStretch(i, 1);
        m_grid->setColumnStretch(i, 1);
    }
}

void VideoGrid::select(VideoCell *cell)
{
    if (m_selected)
        m_selected->setSelected(false);
    m_selected = cell;
    if (m_selected)
        m_selected->setSelected(true);
}

void VideoGrid::toggleMaximize(VideoCell *cell)
{
    if (m_maximized)
        m_maximized = nullptr;
    else if (m_count > 1)
        m_maximized = cell;
    applyLayout();
    select(cell);
    refreshCells();   // развёрнутая ячейка играет основной поток
}

void VideoGrid::placeCamera(VideoCell *cell, const QString &cameraId)
{
    if (const CameraEntry *e = m_mgr->find(cameraId))
        cell->play(e->id, e->name, urlFor(*e, cell));
}

QUrl VideoGrid::urlFor(const CameraEntry &e, const VideoCell *cell) const
{
    const bool wantMain = (m_count == 1) || (cell == m_maximized);
    return QUrl((wantMain || e.liveUrl.isEmpty()) ? e.url : e.liveUrl);
}

void VideoGrid::openCamera(const QString &cameraId)
{
    if (m_maximized)
        toggleMaximize(m_maximized);

    VideoCell *target = nullptr;
    if (m_selected && m_selected->isVisible() && m_selected->isEmpty())
        target = m_selected;
    if (!target) {
        for (VideoCell *c : std::as_const(m_cells)) {
            if (c->isVisible() && c->isEmpty()) {
                target = c;
                break;
            }
        }
    }
    if (!target)
        target = (m_selected && m_selected->isVisible()) ? m_selected : m_cells.first();

    placeCamera(target, cameraId);

    // выделяем следующую свободную ячейку, чтобы можно было открывать камеры подряд
    VideoCell *next = target;
    for (VideoCell *c : std::as_const(m_cells)) {
        if (c->isVisible() && c->isEmpty()) {
            next = c;
            break;
        }
    }
    select(next);
}

void VideoGrid::clearAll()
{
    for (VideoCell *c : std::as_const(m_cells))
        c->clear();
}

void VideoGrid::refreshCells()
{
    for (VideoCell *c : std::as_const(m_cells)) {
        if (c->isEmpty())
            continue;
        const CameraEntry *e = m_mgr->find(c->cameraId());
        if (!e) {
            c->clear();                       // камера удалена
        } else if (urlFor(*e, c) != c->url()) {
            placeCamera(c, e->id);            // сменился адрес или нужный поток
        } else {
            c->setTitle(e->name);
        }
    }
}
