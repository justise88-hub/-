#pragma once

#include <QList>
#include <QUrl>
#include <QWidget>

class CameraManager;
struct CameraEntry;
class QGridLayout;
class VideoCell;

// Мозаика 1 / 2×2 / 3×3 / 4×4 ячеек с выделением, разворотом ячейки на всю область
// (двойной щелчок) и перетаскиванием камер.
class VideoGrid : public QWidget {
    Q_OBJECT
public:
    explicit VideoGrid(CameraManager *mgr, QWidget *parent = nullptr);

    int layoutCount() const { return m_count; }

public slots:
    void setLayoutCount(int n);               // 1, 4, 9 или 16
    void openCamera(const QString &cameraId); // в выбранную или первую свободную ячейку
    void clearAll();
    void refreshCells();                      // после изменения списка камер
    void toggleMaximize(VideoCell *cell);

private:
    void applyLayout();
    void select(VideoCell *cell);
    void placeCamera(VideoCell *cell, const QString &cameraId);
    // Подпоток для мозаики; основной поток — при раскладке 1×1 и в развёрнутой ячейке
    QUrl urlFor(const CameraEntry &e, const VideoCell *cell) const;

    CameraManager *m_mgr;
    QGridLayout *m_grid = nullptr;
    QList<VideoCell *> m_cells;
    VideoCell *m_selected = nullptr;
    VideoCell *m_maximized = nullptr;
    int m_count = 4;
};
