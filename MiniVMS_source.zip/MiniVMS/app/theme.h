#pragma once

#include <QString>

// Серо-жёлтая тема: графитовые панели, янтарно-жёлтый акцент (#f2c200).
inline QString appStyleSheet()
{
    return QStringLiteral(R"(
* { font-size: 13px; }
QWidget { background: #2b2b2d; color: #e6e6e6; }

QToolBar { background: #1a1a1c; border: none; spacing: 2px; padding: 4px 8px; }
QToolBar QLabel { background: transparent; }
QWidget#spacer { background: transparent; }
QToolBar QToolButton { background: transparent; color: #b4b4b8; padding: 8px 18px;
                       border: none; border-radius: 4px; font-weight: 600; }
QToolBar QToolButton:hover { background: #333336; color: #ffffff; }
QToolBar QToolButton:checked { background: #f2c200; color: #1a1a1c; }
QLabel#brand { color: #f2c200; font-size: 16px; font-weight: 700; padding: 0 16px 0 4px; }
QLabel#clock { color: #b4b4b8; padding: 0 8px; }
QStatusBar { background: #1a1a1c; color: #9a9a9e; }
QStatusBar QLabel { background: transparent; color: #9a9a9e; }

QPushButton, QToolButton { background: #3a3a3d; border: 1px solid #4a4a4e;
                           border-radius: 4px; padding: 5px 12px; }
QPushButton:hover, QToolButton:hover { background: #46464a; border-color: #f2c200; }
QPushButton:pressed { background: #f2c200; color: #1a1a1c; }
QPushButton:disabled, QToolButton:disabled { color: #6a6a6e; border-color: #3a3a3d; }
QToolButton:checked { background: #f2c200; border-color: #f2c200; color: #1a1a1c; }

QLineEdit, QComboBox, QDateEdit, QSpinBox { background: #202022; border: 1px solid #4a4a4e;
                                            border-radius: 4px; padding: 4px 6px;
                                            selection-background-color: #f2c200;
                                            selection-color: #1a1a1c; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border-color: #f2c200; }
QComboBox QAbstractItemView { background: #202022; selection-background-color: #f2c200;
                              selection-color: #1a1a1c; }

QTreeWidget, QTableWidget, QListWidget { background: #232325; border: 1px solid #3a3a3d;
                                         gridline-color: #333336; }
QTreeWidget::item, QListWidget::item { padding: 3px 2px; }
QTreeWidget::item:selected, QTableWidget::item:selected, QListWidget::item:selected {
    background: #f2c200; color: #1a1a1c; }
QHeaderView::section { background: #3a3a3d; color: #d0d0d4; border: none;
                       border-right: 1px solid #232325; padding: 6px; }

QGroupBox { border: 1px solid #3a3a3d; border-radius: 4px; margin-top: 14px; padding-top: 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; color: #f2c200; }
QSplitter::handle { background: #1a1a1c; }
QSlider::groove:horizontal { height: 4px; background: #4a4a4e; border-radius: 2px; }
QSlider::handle:horizontal { width: 12px; margin: -5px 0; border-radius: 6px; background: #f2c200; }
QProgressBar { background: #202022; border: 1px solid #4a4a4e; border-radius: 4px;
               text-align: center; color: #e6e6e6; }
QProgressBar::chunk { background: #f2c200; border-radius: 3px; }
QCalendarWidget QAbstractItemView { selection-background-color: #f2c200; selection-color: #1a1a1c; }
QScrollBar:vertical { background: #232325; width: 12px; }
QScrollBar::handle:vertical { background: #4a4a4e; border-radius: 5px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: #f2c200; }
QScrollBar:horizontal { background: #232325; height: 12px; }
QScrollBar::handle:horizontal { background: #4a4a4e; border-radius: 5px; min-width: 24px; }
QScrollBar::handle:horizontal:hover { background: #f2c200; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; }

VideoCell { background: #121213; border: 2px solid #3a3a3d; }
VideoCell[selected="true"] { border: 2px solid #f2c200; }
VideoCell QWidget#cellBar { background: #3a3a3d; }
VideoCell QLabel#cellTitle { background: #3a3a3d; color: #f2f2f2; padding: 2px 8px; }
VideoCell QLabel#placeholder { background: #121213; color: #5a5a5e; }
VideoCell QToolButton { background: transparent; border: none; padding: 2px 8px; }
VideoCell QToolButton:hover { background: #a02b2b; color: #ffffff; }
)");
}
