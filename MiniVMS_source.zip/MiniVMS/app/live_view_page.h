#pragma once

#include <QHash>
#include <QWidget>

#include "core/camera_worker.h"

class CameraManager;
class CameraTree;
class QLineEdit;
class QTreeWidgetItem;
class VideoGrid;

// Главный экран: слева список камер и панель PTZ, справа мозаика видео.
class LiveViewPage : public QWidget {
    Q_OBJECT
public:
    explicit LiveViewPage(CameraManager *mgr, QWidget *parent = nullptr);

private slots:
    void rebuildTree();
    void updateState(const QString &id, CameraWorker::State state);
    void applyFilter(const QString &text);

private:
    CameraManager *m_mgr;
    CameraTree *m_tree = nullptr;
    QLineEdit *m_search = nullptr;
    VideoGrid *m_grid = nullptr;
    QHash<QString, QTreeWidgetItem *> m_items;
};
