#pragma once

#include <QMainWindow>

class CameraManager;
class EventsPage;
class QLabel;
class QStackedWidget;

// Оболочка в стиле iVMS: сверху вкладки (Просмотр / Архив / Устройства / Журнал) и часы,
// по центру страницы, снизу строка состояния.
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(CameraManager *mgr, QWidget *parent = nullptr);

protected:
    void closeEvent(QCloseEvent *e) override;

private:
    void updateStatus();

    CameraManager *m_mgr;
    QStackedWidget *m_stack = nullptr;
    EventsPage *m_events = nullptr;
    QLabel *m_clock = nullptr;
    QLabel *m_status = nullptr;
};
