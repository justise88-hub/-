#pragma once

#include <QList>
#include <QMimeData>
#include <QTreeWidget>

#include "app/common.h"

// Дерево «группа → камера». Элемент камеры хранит id в Qt::UserRole
// и при перетаскивании отдаёт его в MIME kCameraMime.
class CameraTree : public QTreeWidget {
public:
    using QTreeWidget::QTreeWidget;

protected:
    QMimeData *mimeData(const QList<QTreeWidgetItem *> &items) const override
    {
        for (const QTreeWidgetItem *it : items) {
            const QString id = it->data(0, Qt::UserRole).toString();
            if (!id.isEmpty()) {
                auto *m = new QMimeData;
                m->setData(QString::fromLatin1(kCameraMime), id.toUtf8());
                return m;
            }
        }
        return nullptr;
    }
};
