// Консольная проверка модуля записи (без GUI):
//   recorder_cli <папка_архива> <rtsp-url> [<rtsp-url> ...]
// Останавливается по Ctrl+C.

#include <QCoreApplication>
#include <QDir>
#include <QMetaEnum>
#include <QTimer>

#include <atomic>
#include <csignal>
#include <cstdio>

#include "core/camera_worker.h"

static std::atomic<bool> g_quit{false};
static void onSignal(int) { g_quit = true; }

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    const QStringList args = app.arguments().mid(1);
    if (args.size() < 2) {
        std::fprintf(stderr, "Использование: recorder_cli <папка_архива> <rtsp-url> [<rtsp-url> ...]\n");
        return 1;
    }

    const QString root = args.first();
    QDir().mkpath(root);
    const QString dbPath = root + QStringLiteral("/index.sqlite");

    QList<CameraWorker *> workers;
    for (int i = 1; i < args.size(); ++i) {
        CameraConfig cfg;
        cfg.id = QStringLiteral("cam%1").arg(i);
        cfg.name = QStringLiteral("Камера %1").arg(i);
        cfg.url = args.at(i);
        cfg.storageRoot = root;
        cfg.dbPath = dbPath;
        cfg.segmentSeconds = 60;   // для теста короткие сегменты

        auto *w = new CameraWorker(cfg, &app);

        QObject::connect(w, &CameraWorker::stateChanged, &app,
            [](const QString &id, CameraWorker::State s) {
                qInfo().noquote() << id << "состояние:"
                                  << QMetaEnum::fromType<CameraWorker::State>().valueToKey(int(s));
            });
        QObject::connect(w, &CameraWorker::segmentStarted, &app,
            [](const QString &id, const QString &path, qint64) {
                qInfo().noquote() << id << "начат сегмент" << path;
            });
        QObject::connect(w, &CameraWorker::segmentFinished, &app,
            [](const QString &id, const QString &path, qint64 s, qint64 e, qint64 size) {
                qInfo().noquote() << id << "завершён" << path
                                  << QStringLiteral("(%1 с, %2 КБ)").arg((e - s) / 1000).arg(size / 1024);
            });
        QObject::connect(w, &CameraWorker::errorOccurred, &app,
            [](const QString &id, const QString &msg) {
                qWarning().noquote() << id << "ошибка:" << msg;
            });

        workers << w;
        w->startRecording();
    }

    std::signal(SIGINT, onSignal);
    std::signal(SIGTERM, onSignal);
    QTimer poll;
    QObject::connect(&poll, &QTimer::timeout, &app, [&] { if (g_quit) app.quit(); });
    poll.start(200);

    const int rc = app.exec();

    for (auto *w : workers) w->stop();
    for (auto *w : workers) w->wait();
    return rc;
}
