@echo off
REM ============================================================
REM  Build MiniVMS.exe on Windows
REM  Requirements:
REM    1) Visual Studio 2022 with "Desktop development with C++"
REM    2) Qt 6.5+ for MSVC 2022 64-bit (Qt Multimedia + Qt SQL)
REM    3) vcpkg (https://github.com/microsoft/vcpkg)
REM  Edit the two paths below, then run this file.
REM ============================================================
set QT_DIR=C:\Qt\6.8.1\msvc2022_64
set VCPKG_ROOT=C:\vcpkg

if not exist "%QT_DIR%\bin\windeployqt.exe" (
    echo Qt not found in %QT_DIR%
    exit /b 1
)
if not exist "%VCPKG_ROOT%\vcpkg.exe" (
    echo vcpkg not found in %VCPKG_ROOT%
    exit /b 1
)

echo [1/4] Installing FFmpeg via vcpkg...
"%VCPKG_ROOT%\vcpkg.exe" install ffmpeg:x64-windows || exit /b 1

echo [2/4] Configuring...
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 ^
  -DCMAKE_PREFIX_PATH="%QT_DIR%" ^
  -DCMAKE_TOOLCHAIN_FILE="%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" || exit /b 1

echo [3/4] Building...
cmake --build build --config Release || exit /b 1

echo [4/4] Collecting Qt libraries next to the exe...
"%QT_DIR%\bin\windeployqt.exe" --release --no-translations build\Release\MiniVMS.exe || exit /b 1

echo.
echo Done. Ready-to-run folder: build\Release   (MiniVMS.exe)
